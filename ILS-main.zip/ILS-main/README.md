# ILS

### Installation
#### 1. Set up an SSH key
Please create an SSH key and add it to GitHub.    
https://docs.github.com/en/authentication/connecting-to-github-with-ssh/adding-a-new-ssh-key-to-your-github-account

#### 2. Set up Git
Set your name and email address on your local machine
```
$ git config --global user.name "Tomoko Nitta"
$ git config --global user.email t-nitta@iis.u-tokyo.ac.jp
```

Check the settings
```
$ git config --global --list
```

#### 3. Download ILS
```
$ cd YOUR-WORKING-DIRECTORY
$ git clone git@github.com:integrated-land-simulator/ILS.git
$ cd ILS
```

#### 4. Create a branch 
```
$ git checkout -b ILS-test origin/main
```

#### 5. Download data for offline land experiments
Data is under preparation.

For isotope3 users, please create a link to the following directory.
```
ln -s /data22/nitta/ILS_data/ILS_data_20221201 ILS_data
```

#### 6. Compile and test run
Set an environment variable
```
$ export ILS_SYS=isotope3
```

(for isotope2/isotope3 users)
Select MPI
```
$ mpi-selector-menu
```

(for non-isotope3 users)
Edit sysdep/Makedef.isotope3
```
$ vi src/sysdep/Makedef.isotope3
```

Compile
```
$ cd ..   
$ make all  
```

Run a test simulation
```
$ cd runs  
$ vi run.sh  
Please change DIR to your directory  
$ qsub run.sh  
```

#### 7. See results
```
$ cd out
$ ncview Qle.nc
```


If you have any questions or issues, please feel free to ask in the "user" channel on ILS Slack!  
https://ils-development.slack.com  
If you haven't joined Slack yet, please contact Nitta at t-nitta@iis.u-tokyo.ac.jp  


### Documents
- [MATSIRO](https://github.com/integrated-land-simulator/model_description/blob/master/convert/descript.pdf)
- [I/O module](https://github.com/integrated-land-simulator/model_description/blob/master/manual/ILSIO_users_guide.pdf)
- [Coupler](https://github.com/integrated-land-simulator/model_description/blob/master/manual/ils_coupling_manual_ver3.0.md)


