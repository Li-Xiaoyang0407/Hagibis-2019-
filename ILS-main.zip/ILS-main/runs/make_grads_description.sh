#!/bin/sh
for i in `ls -1 *nc | sed s/.nc//`;do
OUTDATA="DSET ^${i}.nc\n"
for v in `ncdump -h ${i}.nc | sed -n 3,6p | awk '{print $1}'`;do
OUTDATA=${OUTDATA}`echo ${v} | awk '
  {
    if (substr($1, 1, 3) == "lon"){
       print "XDEF " $1
    }else if(substr($1, 1, 3) == "lat"){
       print "YDEF " $1
    }else if(substr($1, 1, 3) == "dep"){
       print "ZDEF " $1
    }else if(substr($1, 1, 3) == "num"){
       print "ZDEF " $1
    }else if(substr($1, 1, 3) == "tim"){
       print "TDEF " $1
    }}'`
OUTDATA=${OUTDATA}"\n"
done
echo -e ${OUTDATA} > ${i}.ctl
done
