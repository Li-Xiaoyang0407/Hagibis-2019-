#!/bin/sh

# Settings
DIR=`dirname ${PWD}`

PROGMAT=exe_matsiro
PROGCAMA=exe_cama411
PROGIO=ilsio
COMMAND=${DIR}/src/bin/${PROGMAT}
COMMANDC=${DIR}/src/bin/${PROGCAMA}
COMMANDIO=${DIR}/src/bin/${PROGIO}

ODIR=${DIR}/runs/out
if [ ! -d ${ODIR} ]; then
    mkdir ${ODIR}
fi

LOGDIR=${ODIR}/coupling_log
if [ ! -d ${LOGDIR} ]; then
    mkdir ${LOGDIR}
fi

RESTARTDIR=${ODIR}/coupling_restart_data
if [ ! -d ${RESTARTDIR} ]; then
    mkdir ${RESTARTDIR}
fi

CPLDIR=${ODIR}/coupling_internal_data
if [ ! -d ${CPLDIR} ]; then
    mkdir ${CPLDIR}
fi

cp -f ${DIR}/runs/matsiro.conf ${ODIR}
cp -f ${DIR}/runs/cama.conf ${ODIR}/input_cmf.nam
cp -f ${DIR}/runs/ilsio.conf ${ODIR}
cp -f ${DIR}/runs/coupling.conf ${ODIR}
cp -f ${DIR}/runs/ILS.json ${ODIR}
cd ${ODIR}

../set_makeinfo.sh ${DIR}/src/bin/makeinfo.txt

# Run
date
mpiexec -n 16 ${COMMAND} : -n 7 ${COMMANDC} : -n 1 ${COMMANDIO}
date

../make_grads_description.sh
