#!/bin/sh
#PBS -l nodes=2:ppn=12

# Settings
DIR=`dirname ${PBS_O_WORKDIR}`/../
PROGMAT=exe_matsiro
PROGCAMA=exe_cama411_sed
PROGIO=ilsio
COMMAND=${DIR}/src/bin/${PROGMAT}
COMMANDC=${DIR}/src/bin/${PROGCAMA}
COMMANDIO=${DIR}/src/bin/${PROGIO}

ODIR=${DIR}/runs/out_sed
mkdir ${ODIR}
cp -f ${DIR}/runs/run_cama_sediment/matsiro.conf ${ODIR}
cp -f ${DIR}/runs/run_cama_sediment/cama.conf ${ODIR}/input_cmf.nam
cp -f ${DIR}/runs/run_cama_sediment/ilsio_sed.conf ${ODIR}/ilsio.conf
cp -f ${DIR}/runs/run_cama_sediment/coupling_sed.conf ${ODIR}/coupling.conf
cp -f ${DIR}/runs/run_cama_sediment/ILS_sed.json ${ODIR}/ILS.json
cp -f ${DIR}/runs/run_cama_sediment/sediment.conf ${ODIR}/input_sed.nam
cd ${ODIR}

../set_makeinfo.sh ${DIR}/src/bin/makeinfo.txt

# Run
date
mpiexec -n 16 ${COMMAND} : -n 7 ${COMMANDC} : -n 1 ${COMMANDIO}
date

../make_grads_description.sh
