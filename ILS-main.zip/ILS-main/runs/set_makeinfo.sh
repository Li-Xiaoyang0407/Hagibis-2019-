#!/bin/sh
cp ILS.json ILS.json.tmp
INLINE=`grep --color=never -n variable_entry ILS.json.tmp | sed -e 's/:.*//g'`
INLINE=`expr $INLINE - 3`
sed -e "${INLINE}r $1" ILS.json.tmp > ILS.json
