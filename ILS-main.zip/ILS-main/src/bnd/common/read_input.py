import os
import numpy as np
from common.ils_error import ILS_Error

class InputData:
    def __init__(self, directory, filename_format, tiles):
        self.directory = directory
        self.filename_format = filename_format
        self.tiles = self._read_tiles(directory, tiles)

    def read(self, tile, dtype='float32'):
        if tile not in self.tiles:
            raise ILS_Error("Please check the tile name %s"%tile)

        path = os.path.join(self.directory, self.filename_format%tile)
        return np.fromfile(path, dtype=dtype).byteswap()

    def get_tiles(self):
        return self.tiles

    def _read_tiles(self, directory, tiles):
        if isinstance(tiles, list):
            return tiles
        elif isinstance(tiles, str):
            path = os.path.join(directory, tiles)
            f = open(path)
            d = f.readlines()
            d = [i.strip() for i in d]
            f.close()
            return d

