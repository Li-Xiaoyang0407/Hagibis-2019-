import os
import numpy as np

class MappingTable:
    def __init__(self, directory):
        self.directory = directory

    def read_idx(self, input_tile, output_tile):
        try:
            path = os.path.join(self.directory,
                                'mapping_table_idx_%s_%s.bin'
                                    %(input_tile,output_tile))
            if os.path.getsize(path) == 0:
                return None
            else:
                map_idx = np.fromfile(path, dtype='int32')
                map_idx = map_idx.byteswap().reshape(2,-1)
                return map_idx
        except FileNotFoundError:
            return None

    def read_area(self, input_tile, output_tile):
        try:
            path = os.path.join(self.directory,
                                'mapping_table_area_%s_%s.bin'
                                    %(input_tile,output_tile))
            if os.path.getsize(path) == 0:
                return None
            else:
                map_area = np.fromfile(path, dtype='float64')
                map_area = map_area.byteswap()
                return map_area
        except FileNotFoundError:
            return None

