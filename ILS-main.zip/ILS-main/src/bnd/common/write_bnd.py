import os
import numpy as np
from common.ils_error import ILS_Error

class OutputData:
    def __init__(self, var, config, key, dtype='float32'):
        self.var = var
        self.directory = config.get_str(key,'output_dir')
        self.file_type = config.get_str(key,'output_filetype')
        self.tiles = config.get_list(key,'output_tiles')
        self.nx = config.get_int(key,'output_nx')
        self.ny = config.get_int(key,'output_ny')
        self.nxy = self.nx * self.ny
        self.nt = config.get_int(key,'output_nt')
        self.data = np.zeros((self.nt,self.ny,self.nx))
        self.dtype = dtype

    def clear_data(self):
        self.data = np.zeros((self.nt,self.ny,self.nx))

    def write(self, tile):
        if tile not in self.tiles:
            raise ILS_Error("Please check the tile name %s" % tile)

        if self.file_type == 'binary':
            self.write_binary(tile)
        elif self.file_type == 'gtool':
            self.write_gtool(tile)
        elif self.file_type == 'netcdf':
            self.write_gtool(tile)

    def write_binary(self, tile):
        suffix = 'bin'
        path = os.path.join(
                   self.directory,
                   '%s_%s.%s'%(self.var,tile,suffix))
        self.data.astype(self.dtype).byteswap().tofile(path)

    def write_gtool(self):
        raise ILS_Error("Gtool has not been implemented yet")

    def write_netcdf(self):
        raise ILS_Error("netCDF has not been implemented yet")

    def print_valid_file_types(self):
        print("valid types: float32")

    def get_directory(self):
        return self.directory

    def get_file_type(self):
        return self.file_type

    def get_tiles(self):
        return self.tiles
