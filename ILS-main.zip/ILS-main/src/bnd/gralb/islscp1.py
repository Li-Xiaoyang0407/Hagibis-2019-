import os
import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.basemap import Basemap
from common.interp import sum_data
from common.read_input import InputData
from common.read_map import MappingTable
from common.write_bnd import OutputData

def main(config):
    config_key = 'gralb islscp1'
    config.write_log(config_key)

    missing_value = -999.
    fill_value_vis = 0.1
    fill_value_nir = 0.15

    # m = Basemap(
    #         llcrnrlon=-180.,
    #         llcrnrlat=-90,
    #         urcrnrlon=180.,
    #         urcrnrlat=90.,
    #         resolution='l',
    #         projection='cyl',
    #         )

    # Read data
    nx0 = 360
    ny0 = 180
    path = os.path.join(
               config.get_str(config_key,'islscp1_data_dir'),
               'BKGRDVIS.BRF')
    f = open(path)
    d = f.readlines()
    d = np.array([i.split() for i in d], dtype='float64').reshape(-1)
    data_alb_vis = np.ma.masked_equal(d,0).filled(missing_value)
    f.close()

    path = os.path.join(
               config.get_str(config_key,'islscp1_data_dir'),
               'BKGRDNIR.BRF')
    f = open(path)
    d = f.readlines()
    d = np.array([i.split() for i in d], dtype='float64').reshape(-1)
    data_alb_nir = np.ma.masked_equal(d,0).filled(missing_value)
    f.close()

    # plt.figure(figsize=(18,10))
    # m.drawcoastlines()
    # m.drawparallels(
    #     np.arange(-90,91,30),
    #     labels=[1,0,0,1],
    #     )
    # m.drawmeridians(
    #     np.arange(0,360,30),
    #     labels=[1,0,0,1],
    #     )
    # m.imshow(np.ma.masked_equal(data_alb_vis.reshape(ny0,nx0),-999),
    #          interpolation='nearest',
    #          origin='upper')
    # plt.colorbar()
    # plt.tight_layout()
    # plt.show()

    # mapping table
    map_islscp1 = MappingTable(config.get_str(config_key,'islscp1_map_dir'))

    # land mask
    land_mask = InputData(
                    config.get_str(config_key,
                                   'land_mask_dir'),
                    'land_mask_%s.bin',
                    'all_tiles.txt',
                    )

    # output data
    output_gralb = OutputData('gralb', config, config_key)
    output_gralbn = OutputData('gralbn', config, config_key)


    for output_tile in output_gralb.tiles:
        map_idx = map_islscp1.read_idx('global',output_tile)
        if map_idx is None:
            continue
        map_area = map_islscp1.read_area('global',output_tile)

        total_alb_vis = np.zeros(output_gralb.nxy,dtype='float64')
        weight_alb_vis = np.zeros(output_gralb.nxy,dtype='float64')

        total_alb_nir = np.zeros(output_gralb.nxy,dtype='float64')
        weight_alb_nir = np.zeros(output_gralb.nxy,dtype='float64')


        sum_data(map_idx.T,map_area,data_alb_vis,
                 missing_value,total_alb_vis,weight_alb_vis)

        sum_data(map_idx.T,map_area,data_alb_nir,
                 missing_value,total_alb_nir,weight_alb_nir)


        gralb = np.ma.divide(total_alb_vis,np.ma.masked_equal(weight_alb_vis,0))
        if np.ma.is_masked(gralb):
            gralb = gralb.filled(fill_value_vis)

        gralbn = np.ma.divide(total_alb_nir,np.ma.masked_equal(weight_alb_nir,0))
        if np.ma.is_masked(gralbn):
            gralbn = gralbn.filled(fill_value_nir)

        lmask = land_mask.read(output_tile)
        sea_mask = np.ma.masked_equal(lmask,0).mask

        gralb[sea_mask] = 0.
        gralbn[sea_mask] = 0.

        output_gralb.data[0,:,:] = gralb.reshape(output_gralb.ny,output_gralb.nx)
        output_gralbn.data[0,:,:] = gralbn.reshape(output_gralbn.ny,output_gralbn.nx)
        output_gralb.write(output_tile)
        output_gralbn.write(output_tile)

        # plt.figure(figsize=(18,10))
        # m.drawcoastlines()
        # m.drawparallels(
        #     np.arange(-90,91,30),
        #     labels=[1,0,0,1],
        #     )        
        # m.drawmeridians(
        #     np.arange(0,360,30),
        #     labels=[1,0,0,1],
        #     )
        # m.imshow(gralb.reshape(360,720),
        #          interpolation='nearest',
        #          origin='upper')
        # plt.colorbar() 

        # plt.figure(figsize=(18,10))
        # m.drawcoastlines()
        # m.drawparallels(
        #     np.arange(-90,91,30),
        #     labels=[1,0,0,1],
        #     )        
        # m.drawmeridians(
        #     np.arange(0,360,30),
        #     labels=[1,0,0,1],
        #     )
        # m.imshow(gralbn.reshape(360,720),
        #          interpolation='nearest',
        #          origin='upper')
        # plt.colorbar() 
        # plt.show() 

