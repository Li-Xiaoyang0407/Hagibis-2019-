from common.ils_error import ILS_Error
import gralb.islscp1

def make_gralb(config):
    config.write_log('gralb')

    method = config.get_str('gralb', 'method')
    if method == 'islscp1':
        gralb.islscp1.main(config)
    else:
        raise ILS_Error(
                  "[ILS boundary tool] "
                  "Please check the method for GRALB")

