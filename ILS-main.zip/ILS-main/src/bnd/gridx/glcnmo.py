import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.basemap import Basemap
from common.fill import match_index_with_land_sea_mask
from common.interp import sum_weight
from common.read_input import InputData
from common.read_map import MappingTable
from common.write_bnd import OutputData
import gridx.glcnmo_idx_conv


def main(config):
    """
    Make land surface type GRIDX from the Global Land Cover
    by National Mapping Organizations version 3

    Parameters
    ----------
    config : class instance


    Notes
    -----
    Input
      - GLCNMO (preprocessed)
      - 2m temperature of the hottest month from JRA55 (preprocessed)

    Output
      - GRIDX
    """
    config_key = 'gridx glcnmo'
    config.write_log(config_key)


    # m = Basemap(
    #         llcrnrlon=-180.,
    #         llcrnrlat=-90,
    #         urcrnrlon=180.,
    #         urcrnrlat=90.,
    #         resolution='l',
    #         projection='cyl',
    #         )

    # input data
    input_glcnmo = InputData(
                       config.get_str(config_key,
                                      'glcnmo_data_dir'),
                       'gm_lc_v3_%s.bin',
                       'all_tiles.txt',
                       )

    input_t2max = InputData(
                      config.get_str(config_key,
                                     'jra55_data_dir'),
                      'jra55_tmp2m_max_%s.bin',
                      'all_tiles.txt',
                      )

    # mapping table
    map_glcnmo = MappingTable(
                     config.get_str(config_key,
                                    'glcnmo_map_dir'),
                     )

    # land mask
    land_mask = InputData(
                    config.get_str(config_key,
                                   'land_mask_dir'),
                    'land_mask_%s.bin',
                    'all_tiles.txt',
                    )

    # output data
    output_gridx = OutputData('gridx', config, config_key)


    for output_tile in output_gridx.tiles:
        number_of_gridx_types = 12  # gridx types: 0-11
        weight = np.zeros((number_of_gridx_types,output_gridx.nxy),
                          dtype='float64')

        for input_tile in input_glcnmo.tiles:
            print("[ILS boundary tool] gridx reading glcnmo %s"%input_tile)
            map_idx = map_glcnmo.read_idx(input_tile,output_tile)
            if map_idx is None:
                continue
            map_area = map_glcnmo.read_area(input_tile,output_tile)
            data_in = input_glcnmo.read(input_tile, 'int16')
            data_in = data_in.astype('int32')
            # if input_tile == 'W080S50':
            # if input_tile == 'E130N40':
            #     plt.figure()
            #     plt.imshow(data_in.reshape(2400,2400),
            #                interpolation='nearest')
            #     plt.colorbar()
            #     plt.title(input_tile)
            t2max = read_t2max(input_t2max,input_tile)
            # if input_tile == 'W080S50':
            # if input_tile == 'E130N40':
            #     plt.figure()
            #     plt.imshow(t2max.reshape(2400,2400),
            #                interpolation='nearest')
            #     plt.colorbar()
            #     plt.title(input_tile)
            #     plt.show()
            gridx0 = gridx.glcnmo_idx_conv.convert_index(data_in,t2max)
            missing_value = -999
            # plt.imshow(gridx0.reshape(2400,2400),
            #            interpolation='nearest')
            # plt.colorbar()
            # plt.title(input_tile)
            # plt.show()
            sum_weight(map_idx.T,map_area,
                       gridx0,missing_value,weight.T)


        # exclude ocean grids
        weight[0,:] = 0

        # select indices with maxmum area
        gridx1 = np.argmax(weight, axis=0)
        gridx1 = gridx1.reshape(output_gridx.ny,output_gridx.nx)


        # fill missing values
        lmask = land_mask.read(output_tile)
        lmask = lmask.reshape(output_gridx.ny,output_gridx.nx)
        # m.drawcoastlines()
        # m.drawparallels(
        #     np.arange(-90,91,30),
        #     labels=[1,0,0,1],
        #     )
        # m.drawmeridians(
        #     np.arange(0,360,30),
        #     labels=[1,0,0,1],
        #     )
        # m.imshow(lmask.reshape(360,720),
        #          interpolation='nearest',
        #          origin='upper')
        # plt.colorbar()
        # plt.show()
        fill_value = 10
        gridx1 = match_index_with_land_sea_mask(
                     gridx1.T, lmask.T,
                     1, 11, -999, 0,
                     -999, 11, fill_value,
                     16, False,
                     )
        gridx1 = gridx1.T

        output_gridx.data[0,:,:] = gridx1[:,:]
        output_gridx.write(output_tile)

        # draw gridx
        # plt.figure()
        # m.drawcoastlines()
        # m.drawparallels(
        #     np.arange(-90,91,30),
        #     labels=[1,0,0,1],
        #     )
        # m.drawmeridians(
        #     np.arange(0,360,30),
        #     labels=[1,0,0,1],
        #     )
        # m.imshow(np.ma.masked_equal(gridx1.reshape(360,720),0),
        #          interpolation='nearest',
        #          origin='upper')
        # plt.colorbar()
        # plt.show()



def read_t2max(input_t2max,input_tile):
    data_tmp = input_t2max.read(input_tile)
    data_tmp = data_tmp.reshape(20,20)
    data_t2max = np.zeros((2400,2400))
    for j in range(120):
        for i in range(120):
            data_t2max[j:2400:120,i:2400:120] = data_tmp[:,:]

    return data_t2max.reshape(-1)


