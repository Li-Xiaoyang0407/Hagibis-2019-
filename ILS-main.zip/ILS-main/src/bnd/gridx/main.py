from common.ils_error import ILS_Error
import gridx.glcnmo

def make_gridx(config):
    config.write_log('gridx')

    method = config.get_str('gridx', 'method')
    if method == 'glcnmo':
        gridx.glcnmo.main(config)
    else:
        raise ILS_Error(
                  "[ILS boundary tool] "
                  "Please check the method for GRIDX")

