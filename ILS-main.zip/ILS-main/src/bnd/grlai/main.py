from common.ils_error import ILS_Error
import grlai.modis

def make_grlai(config):
    config.write_log('grlai')

    method = config.get_str('grlai', 'method')
    if method == 'modis':
        grlai.modis.main(config)
    else:
        raise ILS_Error(
                  "[ILS boundary tool] "
                  "Please check the method for GRLAI")


