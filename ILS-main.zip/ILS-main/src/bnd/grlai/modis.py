import os
import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.basemap import Basemap
from common.fill import (fill_missing_value_temporal,
                         match_data_with_land_sea_mask)
from common.interp import sum_data
from common.read_input import InputData
from common.read_map import MappingTable
from common.write_bnd import OutputData

def main(config):
    config_key = 'grlai modis'
    config.write_log(config_key)
    missing_value = -999.
    min_value = 0.001

    # m = Basemap(
    #         llcrnrlon=-180.,
    #         llcrnrlat=-90,
    #         urcrnrlon=180.,
    #         urcrnrlat=90.,
    #         resolution='l',
    #         projection='cyl',
    #         )


    # mapping table
    map_modis = MappingTable(config.get_str(config_key,'modis_map_dir'))

    # land mask
    land_mask = InputData(
                    config.get_str(config_key,'land_mask_dir'),
                    'land_mask_%s.bin',
                    'all_tiles.txt',
                    )

    # output data
    output_grlai = OutputData('grlai', config, config_key)


    for output_tile in output_grlai.tiles:
        grlai = np.zeros((12,output_grlai.nxy))
        lmask = land_mask.read(output_tile)
        lmask = lmask.reshape(output_grlai.ny,output_grlai.nx)

        for mon in range(1,13):
            print("[ILS boundary tool] grlai %s %2.2i"%(output_tile, mon))

            # input data
            input_modis = InputData(
                               os.path.join(
                                   config.get_str(config_key,'modis_data_dir'),
                                   'Lai_1km_all.%2.2i'%mon),
                               'Lai_1km_all.%2.2i.%%s.bin'%mon,
                               'all_tiles.txt',
                               )

            total = np.zeros(output_grlai.nxy,dtype='float64')
            weight = np.zeros(output_grlai.nxy,dtype='float64')

            for input_tile in input_modis.tiles:
                map_idx = map_modis.read_idx(input_tile,output_tile)
                if map_idx is None:
                    continue
                map_area = map_modis.read_area(input_tile,output_tile)

                data_lai_in = input_modis.read(input_tile)
                # if input_tile == 'h09v07':
                #     plt.figure()
                #     plt.imshow(
                #         np.ma.masked_equal(data_lai_in.reshape(1200,1200),
                #         missing_value),
                #         interpolation='nearest')
                #     plt.colorbar()
                #     plt.title(input_tile)
                #     plt.show()

                sum_data(map_idx.T,map_area,data_lai_in,
                         missing_value,total,weight)

            lai_ave = np.ma.divide(total,np.ma.masked_equal(weight,0))
            if np.ma.is_masked(lai_ave):
                lai_ave = lai_ave.filled(missing_value)
            grlai[mon-1,::] = lai_ave


            # plt.figure()
            # m.drawcoastlines()
            # m.drawparallels(
            #     np.arange(-90,91,30),
            #     labels=[1,0,0,1],
            #     )
            # m.drawmeridians(
            #     np.arange(0,360,30),
            #     labels=[1,0,0,1],
            #     )
            # m.imshow(np.ma.masked_equal(grlai[mon-1].reshape(360,720),-999),
            #          interpolation='nearest',
            #          origin='upper')
            # plt.colorbar()
            # plt.show()

        grlai = grlai.reshape(output_grlai.nt,output_grlai.ny,output_grlai.nx)
        grlai = fill_missing_value_temporal(grlai.T, missing_value)
        grlai = grlai.T

        for mon in range(1,13):
            _grlai = match_data_with_land_sea_mask(
                         grlai[mon-1,::].T, lmask.T,
                         missing_value, 0, min_value, min_value,
                         16, False,
                         )
            grlai[mon-1,::] = _grlai.T

        output_grlai.data[:,:,:] = grlai[:,:,:]
        output_grlai.write(output_tile)

        # for mon in range(1,13):
        #     plt.figure()
        #     m.drawcoastlines()
        #     m.drawparallels(
        #         np.arange(-90,91,30),
        #         labels=[1,0,0,1],
        #         )
        #     m.drawmeridians(
        #         np.arange(0,360,30),
        #         labels=[1,0,0,1],
        #         )
        #     m.imshow(np.ma.masked_equal(grlai[mon-1],0),
        #              interpolation='nearest',
        #              vmin=0,
        #              vmax=6,
        #              origin='upper')
        #     plt.colorbar()
        #     plt.title('%2.2i'%mon)
        # plt.show()

