from common.ils_error import ILS_Error

def make_lake(config):
    config.write_log('lake')

    method = config.get_str('lake', 'method')
    if method == 'n/a':
        print("[ILS boundary tool] "
              "Lake data will be prepared later.")
    else:
        raise ILS_Error(
                  "[ILS boundary tool] "
                  "Please check the method for LKDEP/LKFRC")


