from common.ils_error import ILS_Error

def make_river(config):
    config.write_log('river')

    method = config.get_str('river', 'method')
    if method == 'n/a':
        print("[ILS boundary tool] "
              "River data will be prepared later.")
    else:
        raise ILS_Error(
                  "[ILS boundary tool] "
                  "Please check the method for river data")



