#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import resource
import sys
from common.ils_error import ILS_Error
from common.ils_config import ILS_Config
from gridx.main import make_gridx
from topo.main import make_topo
from slidx.main import make_slidx
from gralb.main import make_gralb
from grlai.main import make_grlai
from lake.main import make_lake
from river.main import make_river


def main(path_cfg):
    resource.setrlimit(resource.RLIMIT_STACK,
                       (resource.RLIM_INFINITY,
                        resource.RLIM_INFINITY))
    sys.path.append(os.path.abspath(os.path.dirname(__file__)))

    config = ILS_Config(path_cfg)
    config.write_log("run_all")
    make_output_dir(config)
    bnds = get_bnd_vars(config)

    for bnd in bnds:
        eval('make_%s'%bnd)(config)

    return


def make_output_dir(config):
    output_dir = config.get_str('run_all', 'output_dir')

    if not os.path.isdir(output_dir):
        print('[ILS boundary tool] creating the directory')
        os.makedirs(output_dir)

    return


def get_bnd_vars(config):
    vars = config.get_list('run_all', 'variables')

    vars_all = [
        'gridx',
        'topo',
        'slidx',
        'gralb',
        'grlai',
        'ssnowd',
        'lake',
        'river',
        ]

    # check the variables
    for v in vars:
        if v not in vars_all:
            raise ILS_Error('"%s" is not in the variable list [%s]'
                            % (v, ', '.join(vars_all)))

    # change the order of variables
    vars = [v for v in vars_all if v in vars]

    return vars


if __name__ == '__main__':
    argvs = sys.argv
    if len(argvs) == 1:
        path_cfg = 'run_all.cfg'
    elif len(argvs) == 2:
        path_cfg = argvs[1]
    else:
        raise ILS_Error("Usage: python %s [config file]" % argvs[0])

    main(path_cfg)

