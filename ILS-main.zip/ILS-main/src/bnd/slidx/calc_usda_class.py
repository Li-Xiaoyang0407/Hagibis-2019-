import numpy as np
import pandas as pd
import pyper

def calc_usda_class(sand, silt, clay):
    '''
    calc_usda_class(sand, silt, clay)

    Return SLIDX based on USDA soil texture class
    Sum of sand, silt and clay should be 100

    Ref: https://cran.r-project.org/web/packages/soiltexture/index.html

    Parameters
    ----------
    sand : array
        % weight of sand
    silt : array
        % weight of silt
    clay : array
        % weight of clay

    Returns
    -------
    slidx : array
        SLIDX based on USDA soil texture class (1-12)

    '''
    msk = np.ma.masked_not_equal(sand, -999.).mask
    sand1 = sand[msk]
    silt1 = silt[msk]
    clay1 = clay[msk]

    # sand1 = sand1 * np.float64(100.) / (sand1 + silt1 + clay1)
    # silt1 = silt1 * np.float64(100.) / (sand1 + silt1 + clay1)
    # clay1 = np.float64(100.) - sand1 - silt1

    data_frame = pd.DataFrame(np.concatenate([[sand1],[silt1],[clay1]]).T,
                              columns = ["SAND", "SILT","CLAY"])



    # Calculate USDA class using a R package
    r = pyper.R(use_pandas='True')
    r("library(soiltexture)")
    r("options(max.print=1000000)")

    r.assign("data", data_frame)
    r("colnames(data) <- c('SAND','SILT','CLAY')")
    r(("out <- TT.points.in.classes(tri.data=data, class.sys='USDA.TT',"
      " text.sum=100, PiC.type='l')"))

    out_r = r.get("out")
    out_r = out_r.astype('float64')


    # Apply SOILPARA numbers
                       # Cl   SiCl   SaCl   ClLo SiClLo SaClLo
                       # Lo   SiLo   SaLo     Si   LoSa     Sa
    soilpara = np.array([12,    11,    10,     8,     9,     7,
                          4,     5,     3,     6,     2,     1],
                                                dtype='float64')

    out = np.zeros(out_r.shape[0], dtype='float64')
    for i in range(12):
        out += (np.ma.masked_equal(out, 0).mask.astype('float64')
                * out_r[:,i] * soilpara[i])

    outdata = np.zeros(len(sand), dtype='float64') - 999.
    outdata[msk] = out

    return outdata


if __name__ == '__main__':
    ndata = 1000
    # ndata = 16250
    a = np.random.rand(ndata) * 50
    b = np.random.rand(ndata) * 50

    a[0] = 100.
    b[0] = 0.

    a[1] = 45.
    b[1] = 15.

    a[2] = 20.
    b[2] = 40.

    a[3] = 15.
    b[3] = 80.

    c = 100. - a - b

    a[20:30] = -999.
    b[20:30] = -999.
    c[20:30] = -999.

    slidx = calc_usda_class(a, b, c)
    print("    id:   sand[%]  silt[%]  clay[%]   slidx")
    for i in range(ndata):
        print("%6i: %8.2f %8.2f %8.2f %8.2f"
              % (i, a[i], b[i], c[i], slidx[i]))

