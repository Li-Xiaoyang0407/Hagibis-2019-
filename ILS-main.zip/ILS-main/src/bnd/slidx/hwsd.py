import os
import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.basemap import Basemap
from common.fill import match_index_with_land_sea_mask
from common.interp import sum_data
from common.read_input import InputData
from common.read_map import MappingTable
from common.write_bnd import OutputData
from slidx.calc_usda_class import calc_usda_class

def main(config):
    """
    Make soil type index SLIDX from Harmonized World
    Soil Database (HWSD) v 1.2

    Parameters
    ----------
    conf_path : str
        The file name of the configure file

    Notes
    -----
    Input
      - sand weight fraction from HWSD (10 deg tiles)
      - silt weight fraction from HWSD (10 deg tiles)
      - clay weight fraction from HWSD (10 deg tiles)

    Output
      - SLIDX
    """

    config_key = 'slidx hwsd'
    config.write_log(config_key)

    fill_value = 4
    missing_value = -999

    # m = Basemap(
    #         llcrnrlon=-180.,
    #         llcrnrlat=-90,
    #         urcrnrlon=180.,
    #         urcrnrlat=90.,
    #         resolution='l',
    #         projection='cyl',
    #         )

    # input data
    input_sand = InputData(
                     os.path.join(config.get_str(config_key,'hwsd_data_dir'),'sand'),
                     'HWSD_sand_%s.bin',
                     'all_tiles.txt',
                     )

    input_silt = InputData(
                     os.path.join(config.get_str(config_key,'hwsd_data_dir'),'silt'),
                     'HWSD_silt_%s.bin',
                     'all_tiles.txt',
                     )

    input_clay = InputData(
                     os.path.join(config.get_str(config_key,'hwsd_data_dir'),'clay'),
                     'HWSD_clay_%s.bin',
                     'all_tiles.txt',
                     )

    # mapping table
    map_hwsd = MappingTable(config.get_str(config_key,'hwsd_map_dir'))

    # output data
    output_slidx = OutputData('slidx', config, config_key)

    # land mask
    land_mask = InputData(
                    config.get_str(config_key,'land_mask_dir'),
                    'land_mask_%s.bin',
                    output_slidx.tiles,
                    )

    # gridx
    input_gridx = InputData(
                      config.get_str(config_key,'gridx_dir'),
                      'gridx_%s.bin',
                       output_slidx.tiles,
                      )


    for output_tile in output_slidx.tiles:
        lmask = land_mask.read(output_tile)
        sea_mask = np.ma.masked_equal(lmask,0).mask

        gridx = input_gridx.read(output_tile)
        ice_mask = np.ma.masked_equal(gridx,1).mask

        total_sand = np.zeros(output_slidx.nxy,dtype='float64')
        weight_sand = np.zeros(output_slidx.nxy,dtype='float64')

        total_silt = np.zeros(output_slidx.nxy,dtype='float64')
        weight_silt = np.zeros(output_slidx.nxy,dtype='float64')

        total_clay = np.zeros(output_slidx.nxy,dtype='float64')
        weight_clay = np.zeros(output_slidx.nxy,dtype='float64')


        for input_tile in input_sand.tiles:
            map_idx = map_hwsd.read_idx(input_tile,output_tile)
            if map_idx is None:
                continue
            map_area = map_hwsd.read_area(input_tile,output_tile)

            data_sand_in = input_sand.read(input_tile)
            data_silt_in = input_silt.read(input_tile)
            data_clay_in = input_clay.read(input_tile)
            # if input_tile == 'W080S50':
            # if input_tile == 'E130N40':
            #     plt.figure()
            #     plt.imshow(np.ma.masked_equal(
            #                    data_sand_in.reshape(1200,1200),missing_value),
            #                interpolation='nearest')
            #     plt.colorbar()
            #     plt.title(input_tile)
            #     plt.show()

            sum_data(map_idx.T,map_area,data_sand_in,
                     missing_value,total_sand,weight_sand)

            sum_data(map_idx.T,map_area,data_silt_in,
                     missing_value,total_silt,weight_silt)

            sum_data(map_idx.T,map_area,data_clay_in,
                     missing_value,total_clay,weight_clay)


        sand_ave = np.ma.divide(total_sand,np.ma.masked_equal(weight_sand,0))
        if np.ma.is_masked(sand_ave):
            sand_ave = sand_ave.filled(missing_value)
        silt_ave = np.ma.divide(total_silt,np.ma.masked_equal(weight_silt,0))
        if np.ma.is_masked(silt_ave):
            silt_ave = silt_ave.filled(missing_value)
        clay_ave = np.ma.divide(total_clay,np.ma.masked_equal(weight_clay,0))
        if np.ma.is_masked(clay_ave):
            clay_ave = clay_ave.filled(missing_value)

        slidx = calc_usda_class(sand_ave, silt_ave, clay_ave)
        if np.ma.is_masked(slidx):
            slidx = slidx.filled(0)
        slidx[sea_mask] = 0
        slidx[ice_mask] = 13

        lmask = lmask.reshape(output_slidx.ny,output_slidx.nx)
        slidx = slidx.reshape(output_slidx.ny,output_slidx.nx)
        slidx = match_index_with_land_sea_mask(
                     slidx.T, lmask.T,
                     1, 13, -999, 0,
                     13, 13, fill_value,
                     16, False,
                     )
        slidx = slidx.T
        output_slidx.data[0,:,:] = slidx[:,:]
        output_slidx.write(output_tile)


        # draw slidx
        # plt.figure()
        # m.drawcoastlines()
        # m.drawparallels(
        #     np.arange(-90,91,30),
        #     labels=[1,0,0,1],
        #     )
        # m.drawmeridians(
        #     np.arange(0,360,30),
        #     labels=[1,0,0,1],
        #     )
        # m.imshow(np.ma.masked_equal(slidx.reshape(360,720),-999),
        #          interpolation='nearest',
        #          origin='upper')
        # plt.colorbar()
        # plt.show()


