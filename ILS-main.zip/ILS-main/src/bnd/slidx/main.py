from common.ils_error import ILS_Error
import slidx.hwsd

def make_slidx(config):
    config.write_log('slidx')

    method = config.get_str('slidx', 'method')
    if method == 'hwsd':
        slidx.hwsd.main(config)
    else:
        raise ILS_Error(
                  "[ILS boundary tool] "
                  "Please check the method for SLIDX")

