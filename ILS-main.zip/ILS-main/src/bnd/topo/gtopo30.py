import os
import numpy as np
# import matplotlib.pyplot as plt
# from mpl_toolkits.basemap import Basemap
from common.interp import sum_data, sum_sq_dev
from common.read_input import InputData
from common.read_map import MappingTable
from common.write_bnd import OutputData

def main(config):
    config_key = 'topo gtopo30'
    config.write_log(config_key)

    sea_value = 0
    fill_value = 0.001


    # input data
    input_dem = InputData(
                    os.path.join(
                        config.get_str(config_key,'gtopo30_data_dir'),'dem'),
                    'gtopo30_dem_%s.bin',
                    'all_tiles.txt',
                    )

    input_slope = InputData(
                      os.path.join(
                          config.get_str(config_key,'gtopo30_data_dir'),'slope'),
                      'gtopo30_slope_%s.bin',
                      'all_tiles.txt',
                      )

    # mapping table
    map_gtopo30 = MappingTable(config.get_str(config_key,'gtopo30_map_dir'))

    # land mask
    land_mask = InputData(
                    config.get_str(config_key,'land_mask_dir'),
                    'land_mask_%s.bin',
                    'all_tiles.txt',
                    )


    #-----------------------------------------------------------------
    # grzsd
    #-----------------------------------------------------------------
    print("[ILS boundary tool] topo making grzsd")
    output_grzsd = OutputData('grzsd', config, config_key)

    for output_tile in output_grzsd.tiles:
        lmask = land_mask.read(output_tile)
        sea_mask = np.ma.masked_equal(lmask,0).mask

        # average dem
        total_dem = np.zeros(output_grzsd.nxy,dtype='float64')
        weight_dem = np.zeros(output_grzsd.nxy,dtype='float64')

        for input_tile in input_dem.tiles:
            map_idx = map_gtopo30.read_idx(input_tile,output_tile)
            if map_idx is None:
                continue
            map_area = map_gtopo30.read_area(input_tile,output_tile)

            data_dem_in = input_dem.read(input_tile)
            # if input_tile == 'W080S50':
            # if input_tile == 'E130N40':
            #     plt.figure()
            #     plt.imshow(np.ma.masked_equal(data_dem_in.reshape(1200,1200),-9999),
            #                interpolation='nearest')
            #     plt.colorbar()
            #     plt.title(input_tile)
            #     plt.show()

            missing_value_dem = -9999
            sum_data(map_idx.T,map_area,data_dem_in,
                     missing_value_dem,total_dem,weight_dem)

        dem_ave = np.ma.divide(total_dem,np.ma.masked_equal(weight_dem,0))
        if np.ma.is_masked(dem_ave):
            dem_ave = dem_ave.filled(fill_value)
        dem_ave[sea_mask] = 0.
        # draw_figure(dem_ave.reshape(360,720),0,'average dem')


        # calculate standard deviation of surface height
        total_std = np.zeros(output_grzsd.nxy,dtype='float64')
        weight_std = np.zeros(output_grzsd.nxy,dtype='float64')

        for input_tile in input_dem.tiles:
            map_idx = map_gtopo30.read_idx(input_tile,output_tile)
            if map_idx is None:
                continue
            map_area = map_gtopo30.read_area(input_tile,output_tile)

            data_dem_in = input_dem.read(input_tile)
            missing_value_dem = -9999
            sum_sq_dev(map_idx.T,map_area,data_dem_in,dem_ave,
                       missing_value_dem,total_std,weight_std)


        grzsd = np.ma.divide(total_std,np.ma.masked_equal(weight_std,0))
        grzsd = np.ma.sqrt(grzsd)
        if np.ma.is_masked(grzsd):
            grzsd = grzsd.filled(fill_value)
        grzsd[sea_mask] = 0.
        output_grzsd.data[0,:,:] = grzsd.reshape(output_grzsd.ny,output_grzsd.nx)
        output_grzsd.write(output_tile)

        # draw_figure(grzsd.reshape(360,720),0,'grzsd')


    #-----------------------------------------------------------------
    # grtans
    #-----------------------------------------------------------------
    print("[ILS boundary tool] topo making grtans")
    output_grtans = OutputData('grtans', config, config_key)

    for output_tile in output_grtans.tiles:
        lmask = land_mask.read(output_tile)
        sea_mask = np.ma.masked_equal(lmask,0).mask

        total_slope = np.zeros(output_grtans.nxy,dtype='float64')
        weight_slope = np.zeros(output_grtans.nxy,dtype='float64')

        for input_tile in input_slope.tiles:
            map_idx = map_gtopo30.read_idx(input_tile,output_tile)
            if map_idx is None:
                continue
            map_area = map_gtopo30.read_area(input_tile,output_tile)

            data_slope_in = input_slope.read(input_tile)
            missing_value_slope = -999
            sum_data(map_idx.T,map_area,data_slope_in,
                     missing_value_slope,total_slope,weight_slope)


        grtans = np.ma.divide(total_slope,np.ma.masked_equal(weight_slope,0))
        if np.ma.is_masked(grtans):
            grtans = grtans.filled(fill_value)
        grtans[sea_mask] = 0.
        output_grtans.data[0,:,:] = grtans.reshape(output_grtans.ny,output_grtans.nx)
        output_grtans.write(output_tile)
        # draw_figure(grtans.reshape(360,720),0,'grtans')



# def draw_figure(data, mask_value, title):
#     m = Basemap(
#             llcrnrlon=-180.,
#             llcrnrlat=-90,
#             urcrnrlon=180.,
#             urcrnrlat=90.,
#             resolution='l',
#             projection='cyl',
#             )
#
#     plt.figure(figsize=(18,10))
#     m.drawcoastlines()
#     m.drawparallels(
#         np.arange(-90,91,30),
#         labels=[1,0,0,1],
#         )
#     m.drawmeridians(
#         np.arange(0,360,30),
#         labels=[1,0,0,1],
#         )
#     m.imshow(np.ma.masked_equal(data,mask_value),
#              interpolation='nearest',
#              origin='upper')
#     plt.colorbar()
#     plt.title(title)
#     plt.tight_layout()
#     plt.show()


