from common.ils_error import ILS_Error
import topo.gtopo30

def make_topo(config):
    config.write_log('topo')

    method = config.get_str('topo', 'method')
    if method == 'gtopo30':
        topo.gtopo30.main(config)
    else:
        raise ILS_Error(
                  "[ILS boundary tool] "
                  "Please check the method for GRZSD/GRTANS")

