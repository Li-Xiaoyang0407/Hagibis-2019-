#!/bin/sh

# Execute simulaton with levee
./test_levee.sh

# Simulation without levee
echo "please execute gosh/test1-glb_15min.sh as reference simulation"

