#!/usr/bin/bash

sed -e 's/ici_/mici_/g' ../iici/ici_base.f90 > sed -e 's/jcup_/jmc_/g' >  ./mici_base.f90
sed -e 's/ici_/mici_/g' ../iici/ici_namelist.f90 > sed -e 's/jcup_/jmc_/g' >  ./mici_namelist.f90
sed -e 's/ici_/mici_/g' ../iici/ici_comp.f90 > sed -e 's/jcup_/jmc_/g' >  ./mici_comp.f90
sed -e 's/ici_/mici_/g' ../iici/ici_name_manager.f90 > sed -e 's/jcup_/jmc_/g' >  ./mici_name_manager.f90
sed -e 's/ici_/mici_/g' ../iici/ici_var.f90 > sed -e 's/jcup_/jmc_/g' > ./mici_var.f90
sed -e 's/ici_/mici_/g' ../iici/ici_restart.f90 > sed -e 's/jcup_/jmc_/g' > ./mici_restart.f90
