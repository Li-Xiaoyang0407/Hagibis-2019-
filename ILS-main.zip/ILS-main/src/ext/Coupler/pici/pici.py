import ctypes
import numpy as np
from datetime import datetime, timedelta

icipy = np.ctypeslib.load_library("libicipy.so", "/data17/arakawa/2021ILS/ILS/src/lib")

#=======+=========+=========+=========+=========+=========+=========+=========+

#def ici_split_world(color):

#    icipy.icipy_split_world.argtypes = [
#        ctypes.POINTER(ctypes.c_int32), 
#        ctypes.POINTER(ctypes.c_int32)
#    ]
#    icipy.icipy_split_world.restype = ctypes.c_void_p
    
#    color_ptr = ctypes.byref(ctypes.c_int32(color))

#    comm      = ctypes.c_int32(1)

#    icipy.icipy_split_world(color_ptr, ctypes.byref(comm))

#    return comm.value

#=======+=========+=========+=========+=========+=========+=========+=========+

#def ici_set_my_world(my_world):

#    icipy.icipy_set_my_world.argtypes = [
#        ctypes.POINTER(ctypes.c_int32), 
#    ]
#    icipy.icipy_set_my_world.restype = ctypes.c_void_p
    
#    world = ctypes.byref(ctypes.c_int32(my_world))

#    icipy.icipy_set_my_world(world)


#=======+=========+=========+=========+=========+=========+=========+=========+

#def ici_get_my_world():
   
#    icipy.icipy_get_my_world.argtypes = [
#        ctypes.POINTER(ctypes.c_int32), 
#    ]
#    icipy.icipy_get_my_world.restype = ctypes.c_void_p
    
#    world = ctypes.byref(ctypes.c_int32(1))

#    icipy.icipy_get_my_world(world)

#    return world.value

#=======+=========+=========+=========+=========+=========+=========+=========+

def ici_init(name_model, namelist_file):
   
    icipy.icipy_init.argtypes = [
        ctypes.POINTER(ctypes.c_char), 
        ctypes.POINTER(ctypes.c_int32), 
        ctypes.POINTER(ctypes.c_char), 
        ctypes.POINTER(ctypes.c_int32), 
    ]
    icipy.icipy_init.restype = ctypes.c_void_p
    
    enc_model = name_model.encode("utf-8")
    model     = ctypes.create_string_buffer(enc_model)
    len_model = len(name_model)

    enc_namelist = namelist_file.encode("utf-8")
    namelist     = ctypes.create_string_buffer(enc_namelist)
    len_namelist = len(namelist_file)

    icipy.icipy_init(model, ctypes.byref(ctypes.c_int32(len_model)), \
                     namelist, ctypes.byref(ctypes.c_int32(len_namelist)))


#=======+=========+=========+=========+=========+=========+=========+=========+

def ici_def_grid(grid_name, imax, jmax, kmax, map_l2g):
   
    icipy.icipy_def_grid.argtypes = [
        ctypes.POINTER(ctypes.c_char), 
        ctypes.POINTER(ctypes.c_int32), 
        ctypes.POINTER(ctypes.c_int32), 
        ctypes.POINTER(ctypes.c_int32), 
        ctypes.POINTER(ctypes.c_int32), 
        np.ctypeslib.ndpointer(dtype=np.int32),
        ctypes.POINTER(ctypes.c_int32),
    ]
    icipy.icipy_def_grid.restype = ctypes.c_void_p
    
    grid     = ctypes.create_string_buffer(grid_name.encode("utf-8"))
    len_name = len(grid_name)

    map_len = len(map_l2g)

    icipy.icipy_def_grid(grid, ctypes.byref(ctypes.c_int32(len_name)), \
                               ctypes.byref(ctypes.c_int32(imax)), \
                               ctypes.byref(ctypes.c_int32(jmax)), \
                               ctypes.byref(ctypes.c_int32(kmax)), \
                               map_l2g, \
                               ctypes.byref(ctypes.c_int32(map_len)))

#=======+=========+=========+=========+=========+=========+=========+=========+

def ici_end_grid_def():
    icipy.icipy_end_grid_def()
   
#=======+=========+=========+=========+=========+=========+=========+=========+

def ici_init_time(time_array):

    icipy.icipy_init_time.argtypes = [
        np.ctypeslib.ndpointer(dtype=np.int32),
        ctypes.POINTER(ctypes.c_int32),
    ]
    icipy.icipy_init_time.restype = ctypes.c_void_p
    
    time_len = len(time_array)

    icipy.icipy_init_time(time_array, ctypes.byref(ctypes.c_int32(time_len)))

#=======+=========+=========+=========+=========+=========+=========+=========+

def ici_set_time(time_array, delta_t):

    icipy.icipy_set_time.argtypes = [
        np.ctypeslib.ndpointer(dtype=np.int32),
        ctypes.POINTER(ctypes.c_int32),
        ctypes.POINTER(ctypes.c_int32),
    ]
    icipy.icipy_set_time.restype = ctypes.c_void_p

    time_len = len(time_array)
    
    icipy.icipy_set_time(time_array, ctypes.byref(ctypes.c_int32(time_len)), \
                         ctypes.byref(ctypes.c_int32(delta_t)))

#=======+=========+=========+=========+=========+=========+=========+=========+

def ici_inc_calendar(time_array, delta_t):
    dt = datetime(year   = time_array[0].astype(int), \
                  month  = time_array[1].astype(int), \
                  day    = time_array[2].astype(int), \
                  hour   = time_array[3].astype(int), \
                  minute = time_array[4].astype(int), \
                  second = time_array[5].astype(int))

    delta = timedelta(seconds=delta_t)

    dt = dt + delta

    time_array[0] = dt.year
    time_array[1] = dt.month
    time_array[2] = dt.day
    time_array[3] = dt.hour
    time_array[4] = dt.minute
    time_array[5] = dt.second

#=======+=========+=========+=========+=========+=========+=========+=========+

def ici_put_data_1d(data_name, data):

    icipy.icipy_put_data_1d.argtypes = [
        ctypes.POINTER(ctypes.c_char), 
        ctypes.POINTER(ctypes.c_int32), 
        np.ctypeslib.ndpointer(dtype=np.float64),
        ctypes.POINTER(ctypes.c_int32),
    ]
    icipy.icipy_put_data_1d.restype = ctypes.c_void_p

    
    name_len = len(data_name)
    data_len = len(data)

    icipy.icipy_put_data_1d(ctypes.create_string_buffer(data_name.encode("utf-8")), \
                            ctypes.byref(ctypes.c_int32(name_len)), \
                            data, ctypes.byref(ctypes.c_int32(data_len)))

#=======+=========+=========+=========+=========+=========+=========+=========+

def ici_get_data_1d(data_name, data):

    icipy.icipy_get_data_1d.argtypes = [
        ctypes.POINTER(ctypes.c_char), 
        ctypes.POINTER(ctypes.c_int32), 
        np.ctypeslib.ndpointer(dtype=np.float64),
        ctypes.POINTER(ctypes.c_int32),
        ctypes.POINTER(ctypes.c_int32),
    ]
    icipy.icipy_get_data_1d.restype = ctypes.c_void_p

    
    name_len = len(data_name)
    data_len = len(data)

    is_get_ok = True

    ok_flag = 1

    icipy.icipy_get_data_1d(ctypes.create_string_buffer(data_name.encode("utf-8")), \
                            ctypes.byref(ctypes.c_int32(name_len)), \
                            data, ctypes.byref(ctypes.c_int32(data_len)), \
                            ctypes.byref(ctypes.c_int32(ok_flag)))
    if (ok_flag == 0):
        is_get_ok = FALSE

    return is_get_ok

#=======+=========+=========+=========+=========+=========+=========+=========+

def ici_finalize(is_exchange_data, is_call_finalize):

    icipy.icipy_finalize.argtypes = [
        ctypes.POINTER(ctypes.c_int32),
        ctypes.POINTER(ctypes.c_int32),
    ]
    icipy.icipy_finalize.restype = ctypes.c_void_p

    exchange_flag = 0
    finalize_call_flag = 0

    if (is_exchange_data):
        exchange_flag = 1

    if (is_call_finalize):
        finalize_call_flag =  1

    icipy.icipy_finalize(ctypes.byref(ctypes.c_int32(is_exchange_data)), \
                         ctypes.byref(ctypes.c_int32(is_call_finalize)))

#=======+=========+=========+=========+=========+=========+=========+=========+
