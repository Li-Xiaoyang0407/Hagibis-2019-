import pici as p
import numpy as np

color = 1

new_comm = p.ici_split_world(0)
new_comm = p.ici_split_world(1)

my_name = "python_app"
my_grid = "python_grid"
matsiro_name = "MATSIRO"
matsiro_grid = "matsiro_grid"

init_time = np.array([2000,1,1,0,0,0], dtype = np.int32)
current_time = np.array([2000,1,1,0,0,0], dtype = np.int32)
delta_t = 3600 

p.ici_set_my_world(new_comm)

p.ici_init(my_name, "coupling.conf")

nx = 720
ny = 360
nz = 1

map_l2g = np.arange(1, nx*ny+1, 1, dtype = np.int32)

p.ici_def_grid(my_grid, nx, ny, nz, map_l2g)
p.ici_end_grid_def()

p.ici_init_time(init_time)

data = np.arange(1, nx*ny+1, 1, dtype = np.float64)

p.ici_put_data_1d("pdummy", data)

for t in range(48):
  p.ici_set_time(current_time, delta_t)

  is_get_ok = p.ici_get_data_1d("mdummy", data)

  data = np.arange(1, nx*ny+1, 1, dtype = np.float64)

  p.ici_put_data_1d("pdummy", data)

  p.ici_inc_calendar(current_time, delta_t)

p.ici_finalize(True, True)
