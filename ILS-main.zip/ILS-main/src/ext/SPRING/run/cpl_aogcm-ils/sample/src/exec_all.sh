#!/bin/bash
set -e
set -x
#===============================================================
# Define variables
#===============================================================

# !!! USE ABSOLUTE PATH !!!
dir_spring="/data7/akira/SPRING/dev/SPRING.v01.01.01"
name_run="sample"
dir_set="${dir_spring}/run/cpl_aogcm-ils/${name_run}/set"
dir_out="${dir_spring}/run/cpl_aogcm-ils/${name_run}/out"
dir_FLOW="${dir_spring}/pkg/FLOW_free/run/cpl_aogcm-ils_${name_run}"

lndfrc_min="0.999999d0"
earth_r="6371.d0"
#---------------------------------------------------------------
export dir_spring
export dir_set
export dir_out
export dir_FLOW

export lndfrc_min
export earth_r
#===============================================================
#
#===============================================================
name_step_01="01_rasterize_ogcm"
name_step_02="02_run_FLOW"
name_step_03="03_make_idxmap_rm"
name_step_04="04_make_grid_data_rm"
name_step_05="05_make_grid_data_agcm"
name_step_06="06_make_rt_im"
name_step_07="07_define_lsm"
name_step_08="08_make_grid_data_lsm"
name_step_09="09_make_rt_std"
name_step_10="10_make_rt_land_to_ogcm"
name_step_11="11_merge_rt"
name_step_12="12_final_products"
#---------------------------------------------------------------
export name_step_01
export name_step_02
export name_step_03
export name_step_04
export name_step_05
export name_step_06
export name_step_07
export name_step_08
export name_step_09
export name_step_10
export name_step_11
export name_step_12
#===============================================================
# Run
#===============================================================
./s01_rasterize_ogcm.sh
./s02_run_FLOW.sh
./s03_make_idxmap_rm.sh
./s04_make_grid_data_rm.sh
./s05_make_grid_data_agcm.sh
./s06_make_rt_im.sh
./s07_define_lsm.sh
./s08_make_grid_data_lsm.sh
./s09_make_rt_std.sh
./s10_make_rt_land_to_ogcm.sh
./s11_merge_rt.sh
./s12_copy_final_products.sh
