#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_03}/make_idxmap_rm.conf"
dir_out_this="${dir_out}/${name_step_03}"
#===============================================================
#
#===============================================================
mkdir -p ${dir_set}/${name_step_03}

cat << EOF > ${f_conf}
#

[common]
  is_tiled: .false.
  nx_grid: 720
  ny_grid: 360
  nx_raster_1deg: 60
  ny_raster_1deg: 60
[end]

[cama-flood]
  dir: "${dir_out}/${name_step_02}/map"
  fin_catmxy: "1min/catmxy.bin"
  fin_nextxy: "nextxy.bin"

  dir: "${dir_out_this}"
  fout_grdidx_river    : "grdidx_river.bin"
  fout_grdidx_river_end: "grdidx_river_end.bin"
  fout_grdidx_noriv    : "grdidx_noriv.bin"
  fout_grdidx_ocean    : "grdidx_ocean.bin"
  fout_rstidx_river    : "rstidx_river.bin"
  fout_rstidx_river_end: "rstidx_river_end.bin"
  fout_rstidx_noriv    : "rstidx_noriv.bin"
  fout_rstidx_ocean    : "rstidx_ocean.bin"

  catmxy_noriv_coastal: 0
  catmxy_noriv_inland : -1
  catmxy_ocean        : -9999
  nextxy_river_mouth  : -9
  nextxy_river_inland : -10
  nextxy_ocean        : -9999
  idx_miss: -9999
[end]

[options]
  old_files: remove
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/ext/make_cmf_mat/main.exe ${f_conf}
