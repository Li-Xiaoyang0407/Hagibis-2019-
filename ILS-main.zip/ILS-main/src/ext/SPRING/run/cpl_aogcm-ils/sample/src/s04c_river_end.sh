#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_04}/make_grid_data_rm_river_end.conf"
dir_out_this="${dir_out}/${name_step_04}"
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report_river.txt"

[grid_system_raster]
  nx: 21600
  ny: 10800
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.

  dir: "${dir_out}/${name_step_03}"
  fin_rstidx: "rstidx_river_end.bin"
  fin_grdidx: "grdidx_river_end.bin"
  in_grid_sz: 720, 360

  out_form: index
  dir: "${dir_out_this}"
  fout_grdidx: "grdidx_river_end.bin"
  fout_grdara: "grdara_river_end.bin"
  fout_grdx  : "grdxyz_river_end.bin", rec=1
  fout_grdy  : "grdxyz_river_end.bin", rec=2
  fout_grdz  : "grdxyz_river_end.bin", rec=3
  fout_grdlon: "grdlonlat_river_end.bin", rec=1
  fout_grdlat: "grdlonlat_river_end.bin", rec=2

  idx_miss   : -9999
  ara_miss   : -1d20
  xyz_miss   : -1d20
  lonlat_miss: -1d20
[end]

[options]
  old_files: remove

  earth_shape: sphere
  earth_r: ${earth_r}
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/make_grid_data/main.exe ${f_conf}
