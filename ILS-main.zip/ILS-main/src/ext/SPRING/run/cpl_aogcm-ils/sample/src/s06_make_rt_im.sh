#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
mkdir -p ${dir_set}/${name_step_06}

./s06c_agcm_to_ogcm-ocean.sh
./s06c_ogcm-land_to_agcm.sh
./s06c_rm-river_to_agcm.sh
./s06c_rm-noriv_to_agcm.sh
./s06c_rm-ocean_to_agcm.sh
