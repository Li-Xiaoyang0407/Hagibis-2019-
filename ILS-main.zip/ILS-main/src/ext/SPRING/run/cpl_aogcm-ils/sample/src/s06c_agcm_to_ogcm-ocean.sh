#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_06}/make_rt_agcm_to_ogcm-ocean.conf"
dir_out_this="${dir_out}/${name_step_06}/rt_agcm_to_ogcm-ocean"
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[grid_system_latlon]
  nx: 256
  ny: 128
  dir: "${dir_spring}/dat/T85"
  f_lon_bound: "T85_lon_bound.bin"
  f_lat_bound: "T85_lat_bound.bin"
  is_south_to_north: .false.
[end]

[grid_system_polygon]
  nij: 92160
  np: 4
  dir: "${dir_spring}/dat/COCO/1deg"
  f_lon_vertex: "COCO_lon.bin"
  f_lat_vertex: "COCO_lat.bin"
  coord_unit: degree
  coord_miss: -999.d0
  arc_parallel: .true.
  fin_grdidx: "COCO_idx_ocean.bin"
  idx_miss: 0
[end]

[regridding]
  dir: "${dir_out_this}"
  fout_rt_sidx: "grid.bin", rec=1
  fout_rt_tidx: "grid.bin", rec=2
  fout_rt_area: "area.bin"
  fout_rt_coef: "coef.bin"

  vrf_source_form: auto
  fout_vrf_grdidx     : "vrf/source_idx_auto.bin"
  fout_vrf_grdara_true: "vrf/source_val_auto.bin", rec=1
  fout_vrf_grdara_rt  : "vrf/source_val_auto.bin", rec=2
  fout_vrf_rerr_grdara: "vrf/source_val_auto.bin", rec=3
  fout_vrf_grdnum     : "vrf/source_num_auto.bin"

  vrf_target_form: index
  fout_vrf_grdara_true: "vrf/target_val_fmt.bin", rec=1
  fout_vrf_grdara_rt  : "vrf/target_val_fmt.bin", rec=2
  fout_vrf_rerr_grdara: "vrf/target_val_fmt.bin", rec=3
  fout_vrf_grdnum     : "vrf/target_num_fmt.bin"
[end]

[options]
  old_files: remove

  earth_shape: sphere
  earth_r: ${earth_r}
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/regrid/main.exe ${f_conf}
