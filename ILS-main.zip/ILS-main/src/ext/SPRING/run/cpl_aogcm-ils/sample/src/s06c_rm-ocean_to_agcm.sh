#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_06}/make_rt_rm-ocean_to_agcm.conf"
dir_out_this="${dir_out}/${name_step_06}/rt_rm-ocean_to_agcm"
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[grid_system_raster]
  nx: 21600
  ny: 10800
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.

  dir: "${dir_out}/${name_step_03}"
  fin_rstidx: "rstidx_ocean.bin"
  fin_grdidx: "grdidx_ocean.bin"
  in_grid_sz: 720, 360
  idx_miss: -9999
[end]

[grid_system_latlon]
  nx: 256
  ny: 128
  is_south_to_north: .false.

  dir: "${dir_spring}/dat/T85"
  f_lon_bound: "T85_lon_bound.bin"
  f_lat_bound: "T85_lat_bound.bin"
[end]

[regridding]
  dir: "${dir_out_this}"
  fout_rt_sidx: "grid.bin", rec=1
  fout_rt_tidx: "grid.bin", rec=2
  fout_rt_area: "area.bin"
  fout_rt_coef: "coef.bin"

  vrf_source_form: index
  fout_vrf_grdara_true: "vrf/source_val_fmt.bin", rec=1
  fout_vrf_grdara_rt  : "vrf/source_val_fmt.bin", rec=2
  fout_vrf_rerr_grdara: "vrf/source_val_fmt.bin", rec=3
  fout_vrf_grdnum     : "vrf/source_num_fmt.bin"

  vrf_target_form: auto
  fout_vrf_grdidx     : "vrf/target_idx_auto.bin"
  fout_vrf_grdara_true: "vrf/target_val_auto.bin", rec=1
  fout_vrf_grdara_rt  : "vrf/target_val_auto.bin", rec=2
  fout_vrf_rerr_grdara: "vrf/target_val_auto.bin", rec=3
  fout_vrf_grdnum     : "vrf/target_num_auto.bin"
[end]

[options]
  old_files: remove

  earth_shape: sphere
  earth_r: ${earth_r}
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/regrid/main.exe ${f_conf}
