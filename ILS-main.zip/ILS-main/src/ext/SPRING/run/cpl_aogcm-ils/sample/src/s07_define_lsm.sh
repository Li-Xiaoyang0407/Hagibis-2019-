#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_07}/define_lsm.conf"
dir_out_this=${dir_out}/${name_step_07}
#---------------------------------------------------------------
# Get length of rt
#---------------------------------------------------------------
nij_rt_ogcm_to_agcm\
=`sed -n 3p ${dir_out}/${name_step_06}/rt_ogcm-land_to_agcm/report.txt | cut -d " " -f 2`
nij_rt_rm_river_to_agcm\
=`sed -n 3p ${dir_out}/${name_step_06}/rt_rm-river_to_agcm/report.txt | cut -d ":" -f 2`
nij_rt_rm_noriv_to_agcm\
=`sed -n 3p ${dir_out}/${name_step_06}/rt_rm-noriv_to_agcm/report.txt | cut -d ":" -f 2`
nij_rt_rm_ocean_to_agcm\
=`sed -n 3p ${dir_out}/${name_step_06}/rt_rm-ocean_to_agcm/report.txt | cut -d ":" -f 2`
#===============================================================
#
#===============================================================
mkdir -p ${dir_set}/${name_step_07}

cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[input_rt_ogcm_to_agcm]
  length: ${nij_rt_ogcm_to_agcm}
  dir: "${dir_out}/${name_step_06}/rt_ogcm-land_to_agcm"
  f_send: "grid.bin", rec=1
  f_recv: "grid.bin", rec=2
  f_area: "area.bin"
[end]

[input_rt_rm_river_to_agcm]
  length: ${nij_rt_rm_river_to_agcm}
  dir: "${dir_out}/${name_step_06}/rt_rm-river_to_agcm"
  f_send: "grid.bin", rec=1
  f_recv: "grid.bin", rec=2
  f_area: "area.bin"
[end]

[input_rt_rm_noriv_to_agcm]
  length: ${nij_rt_rm_noriv_to_agcm}
  dir: "${dir_out}/${name_step_06}/rt_rm-noriv_to_agcm"
  f_send: "grid.bin", rec=1
  f_recv: "grid.bin", rec=2
  f_area: "area.bin"
[end]

[input_rt_rm_ocean_to_agcm]
  length: ${nij_rt_rm_ocean_to_agcm}
  dir: "${dir_out}/${name_step_06}/rt_rm-ocean_to_agcm"
  f_send: "grid.bin", rec=1
  f_recv: "grid.bin", rec=2
  f_area: "area.bin"
[end]

[input_agcm]
  nij: 32768
  dir: "${dir_out}/${name_step_05}"
  f_grdidx: "grdidx.bin"
  f_grdara: "grdara.bin"
[end]

[input_rm]
  nx_raster: 21600
  ny_raster: 10800
  nx_grid: 720
  ny_grid: 360

  dir: "${dir_out}/${name_step_03}"
  f_grdidx_river: "grdidx_river.bin"
  f_grdidx_noriv: "grdidx_noriv.bin"
  f_grdidx_ocean: "grdidx_ocean.bin"

  dir: "${dir_out}/${name_step_03}"
  f_rstidx_river: "rstidx_river.bin"
  f_rstidx_noriv: "rstidx_noriv.bin"
  f_rstidx_ocean: "rstidx_ocean.bin"

  dir: "${dir_out}/${name_step_04}"
  f_grdara_river: "grdara_river.bin"
  f_grdara_noriv: "grdara_noriv.bin"
  f_grdara_ocean: "grdara_ocean.bin"

  idx_miss: -9999
[end]

[output_rt_lsm_river_to_agcm]
  dir: "${dir_out_this}/rt_lsm-river_to_agcm"
  f_send: "grid.bin", rec=1, endian=big
  f_recv: "grid.bin", rec=2, endian=big
  f_area: "area.bin", endian=big
  f_coef: "coef.bin", endian=big
[end]

[output_rt_lsm_noriv_to_agcm]
  dir: "${dir_out_this}/rt_lsm-noriv_to_agcm"
  f_send: "grid.bin", rec=1, endian=big
  f_recv: "grid.bin", rec=2, endian=big
  f_area: "area.bin", endian=big
  f_coef: "coef.bin", endian=big
[end]

[output_rt_agcm_to_lsm_river]
  dir: "${dir_out_this}/rt_agcm_to_lsm-river"
  f_send: "grid.bin", rec=1, endian=big
  f_recv: "grid.bin", rec=2, endian=big
  f_area: "area.bin", endian=big
  f_coef: "coef.bin", endian=big
[end]

[output_rt_agcm_to_lsm_noriv]
  dir: "${dir_out_this}/rt_agcm_to_lsm-noriv"
  f_send: "grid.bin", rec=1, endian=big
  f_recv: "grid.bin", rec=2, endian=big
  f_area: "area.bin", endian=big
  f_coef: "coef.bin", endian=big
[end]

[output_agcm]
  dir: "${dir_out_this}/agcm"
  f_lndara_ogcm      : "lndara_ogcm.bin"
  f_lndara_river     : "lndara_river.bin"
  f_lndara_noriv_real: "lndara_noriv_real.bin"
  f_lndara_noriv_virt: "lndara_noriv_virt.bin"
  f_lndara_noriv     : "lndara_noriv.bin"
[end]

[output_lsm]
  dir: "${dir_out_this}/lsm"

  f_lndmsk_river     : "lndmsk_river.bin", real, endian=big
  f_lndmsk_noriv     : "lndmsk_noriv.bin", real, endian=big
  f_lndmsk_noriv_real: "lndmsk_noriv-real.bin", real, endian=big
  f_lndmsk_noriv_virt: "lndmsk_noriv-virt.bin", real, endian=big

  f_grdidx_bnd_river     : "grdidx_bnd_river.bin"
  f_grdidx_bnd_noriv     : "grdidx_bnd_noriv.bin"
  f_grdidx_bnd_noriv_real: "grdidx_bnd_noriv-real.bin"
  f_grdidx_bnd_noriv_virt: "grdidx_bnd_noriv-virt.bin"

  f_grdidx_river     : "grdidx_river.bin"
  f_grdidx_noriv     : "grdidx_noriv.bin"
  f_grdidx_noriv_real: "grdidx_noriv-real.bin"
  f_grdidx_noriv_virt: "grdidx_noriv-virt.bin"

  f_grdara_river     : "grdara_river.bin"
  f_grdara_noriv     : "grdara_noriv.bin"
  f_grdara_noriv_real: "grdara_noriv-real.bin"
  f_grdara_noriv_virt: "grdara_noriv-virt.bin"

  f_grdwgt_river     : "grdwgt_river.bin"
  f_grdwgt_noriv     : "grdwgt_noriv.bin"
  f_grdwgt_noriv_virt: "grdwgt_noriv-virt.bin"
  f_grdwgt_noriv_real: "grdwgt_noriv-real.bin"

  f_rstidx_river     : "rstidx_river.bin"
  f_rstidx_noriv     : "rstidx_noriv.bin"
  f_rstidx_noriv_real: "rstidx_noriv-real.bin"
  f_rstidx_noriv_virt: "rstidx_noriv-virt.bin"

  f_rstidx_bnd_river     : "rstidx_bnd_river.bin"
  f_rstidx_bnd_noriv     : "rstidx_bnd_noriv.bin"
  f_rstidx_bnd_noriv_real: "rstidx_bnd_noriv-real.bin"
  f_rstidx_bnd_noriv_virt: "rstidx_bnd_noriv-virt.bin"
[end]

[options]
  old_files: remove
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/ext/cpl_aogcm-ils_define_mat/main.exe ${f_conf}
