#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_08}/make_grid_data_lsm_river.conf"
dir_out_this="${dir_out}/${name_step_08}"
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report_river.txt"

[grid_system_raster]
  nx: 21600
  ny: 10800
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.

  dir: "${dir_out}/${name_step_07}/lsm"
  fin_rstidx: "rstidx_river.bin"
  fin_grdidx: "grdidx_river.bin"
  in_grid_sz: 720, 360

  out_form: index
  dir: "${dir_out_this}"
  #fout_grdidx: "grdidx_river.bin"
  #fout_grdara: "grdara_river.bin"
  fout_grdx  : "grdxyz_river.bin", rec=1
  fout_grdy  : "grdxyz_river.bin", rec=2
  fout_grdz  : "grdxyz_river.bin", rec=3
  fout_grdlon: "grdlonlat_river.bin", rec=1
  fout_grdlat: "grdlonlat_river.bin", rec=2

  idx_miss   : -9999
  ara_miss   : -1d20
  xyz_miss   : -1d20
  lonlat_miss: -1d20
[end]

[options]
  old_files: remove

  earth_shape: sphere
  earth_r: ${earth_r}
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/make_grid_data/main.exe ${f_conf}

cp ../out/${name_step_07}/lsm/grdidx_river.bin ../out/${name_step_08}/.
cp ../out/${name_step_07}/lsm/grdara_river.bin ../out/${name_step_08}/.
