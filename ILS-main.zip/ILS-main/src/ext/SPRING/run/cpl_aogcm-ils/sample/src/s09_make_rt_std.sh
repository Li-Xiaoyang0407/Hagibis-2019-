#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
mkdir -p ${dir_set}/${name_step_09}

./s09c_io-bnd_to_lsm-river.sh
./s09c_io-bnd_to_lsm-noriv.sh

./s09c_io-met_to_lsm-river.sh
./s09c_io-met_to_lsm-noriv-real.sh
./s09c_io-met_to_lsm-noriv-virt.sh

./s09c_lsm-river_to_rm.sh

./s09c_lsm-river_to_io-row.sh
./s09c_lsm-noriv-real_to_io-row.sh
./s09c_lsm-noriv-virt_to_io-row.sh
./s09c_lsm-river_to_io-rect.sh
./s09c_lsm-noriv-real_to_io-rect.sh
./s09c_lsm-noriv-virt_to_io-rect.sh

./s09c_rm_to_lsm-river.sh
./s09c_rm_to_io-row.sh
