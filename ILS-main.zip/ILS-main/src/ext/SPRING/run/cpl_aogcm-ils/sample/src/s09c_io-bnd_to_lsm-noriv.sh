#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_09}/make_rt_io-bnd_to_lsm-noriv.conf"
dir_out_this="${dir_out}/${name_step_09}/rt_io-bnd_to_lsm-noriv"
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[grid_system_latlon]
  nx: 720
  ny: 360
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.
  idx_bgn: 259201  # second layer
[end]

[grid_system_latlon]
  nx: 720
  ny: 360
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.

  dir: "${dir_out}/${name_step_07}/lsm"
  fin_grdidx: "grdidx_noriv.bin"
  idx_miss: -9999
[end]

[regridding]
  grid_coef: target
  grid_sort: target

  dir: "${dir_out_this}"
  fout_rt_sidx: "grid.bin", int4, 1, big
  fout_rt_tidx: "grid.bin", int4, 2, big
  fout_rt_area: "area.bin", dble, 1, big
  fout_rt_coef: "coef.bin", dble, 1, big
[end]

[options]
  old_files: remove

  earth_shape: sphere
  earth_r: ${earth_r}
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/regrid/main.exe ${f_conf}
