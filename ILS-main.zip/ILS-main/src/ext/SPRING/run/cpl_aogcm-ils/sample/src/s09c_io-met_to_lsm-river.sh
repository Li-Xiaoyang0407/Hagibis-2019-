#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_09}/make_rt_io-met_to_lsm-river.conf"
dir_out_this="${dir_out}/${name_step_09}/rt_io-met_to_lsm-river"
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[grid_system_latlon]
  nx: 720
  ny: 360
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.
[end]

[grid_system_raster]
  nx: 21600
  ny: 10800
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.

  dir: "${dir_out}/${name_step_07}/lsm"
  fin_rstidx: "rstidx_river.bin"
  fin_grdidx: "grdidx_river.bin"
  in_grid_sz: 720, 360
  idx_miss: -9999
[end]

[regridding]
  grid_coef: target
  grid_sort: target

  dir: "${dir_out_this}"
  fout_rt_sidx: "grid.bin", int4, 1, big
  fout_rt_tidx: "grid.bin", int4, 2, big
  fout_rt_area: "area.bin", dble, 1, big
  fout_rt_coef: "coef.bin", dble, 1, big

  vrf_source_form: auto
  fout_vrf_grdidx     : "vrf/source_idx_auto.bin", int4
  fout_vrf_grdara_true: "vrf/source_val_auto.bin", dble, 1
  fout_vrf_grdara_rt  : "vrf/source_val_auto.bin", dble, 2
  fout_vrf_rerr_grdara: "vrf/source_val_auto.bin", dble, 3
  fout_vrf_grdnum     : "vrf/source_num_auto.bin", int4

  vrf_target_form: index
  fout_vrf_grdara_true: "vrf/target_val_fmt.bin", dble, 1
  fout_vrf_grdara_rt  : "vrf/target_val_fmt.bin", dble, 2
  fout_vrf_rerr_grdara: "vrf/target_val_fmt.bin", dble, 3
  fout_vrf_grdnum     : "vrf/target_num_fmt.bin", int4
[end]

[options]
  old_files: remove

  earth_shape: sphere
  earth_r: ${earth_r}
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/regrid/main.exe ${f_conf}
