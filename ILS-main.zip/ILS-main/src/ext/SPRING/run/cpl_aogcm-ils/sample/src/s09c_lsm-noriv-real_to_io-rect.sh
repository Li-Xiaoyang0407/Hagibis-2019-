#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_09}/make_rt_lsm-noriv-real_to_io-rect.conf"
dir_out_this="${dir_out}/${name_step_09}/rt_lsm-noriv-real_to_io-rect"
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
path_report: "${dir_out_this}/report.txt"

[grid_system_raster]
  nx: 21600
  ny: 10800
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.

  dir: "${dir_out}/${name_step_07}/lsm"
  fin_rstidx: "rstidx_noriv-real.bin"
  fin_grdidx: "grdidx_noriv-real.bin"
  in_grid_sz: 720, 360
  idx_miss: -9999
[end]

[grid_system_latlon]
  nx: 720
  ny: 360
  is_south_to_north: .false.

  west: -180
  east:  180
  south: -90
  north:  90
[end]

[regridding]
  grid_coef: target
  grid_sort: target

  opt_coef_sum_modify: 1.d0

  dir: "${dir_out_this}"
  fout_rt_sidx: "grid.bin", rec=1, endian=big
  fout_rt_tidx: "grid.bin", rec=2, endian=big
  fout_rt_area: "area.bin", endian=big
  fout_rt_coef: "coef.bin", endian=big

  vrf_source_form: index
  fout_vrf_grdara_true: "vrf/send_val_fmt.bin", rec=1
  fout_vrf_grdara_rt  : "vrf/send_val_fmt.bin", rec=2
  fout_vrf_rerr_grdara: "vrf/send_val_fmt.bin", rec=3

  vrf_target_form: auto
  fout_vrf_grdidx     : "vrf/recv_idx_auto.bin"
  fout_vrf_grdara_true: "vrf/recv_val_auto.bin", rec=1
  fout_vrf_grdara_rt  : "vrf/recv_val_auto.bin", rec=2
  fout_vrf_rerr_grdara: "vrf/recv_val_auto.bin", rec=3
[end]

[options]
  old_files: remove

  earth_shape: sphere
  earth_r: ${earth_r}
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/regrid/main.exe ${f_conf}
