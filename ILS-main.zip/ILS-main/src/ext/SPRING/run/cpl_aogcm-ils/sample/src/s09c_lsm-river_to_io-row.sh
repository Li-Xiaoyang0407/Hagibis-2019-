#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_09}/make_rt_lsm-river_to_io-row.conf"
dir_out_this="${dir_out}/${name_step_09}/rt_lsm-river_to_io-row"
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[grid_system_latlon]
  nx: 720
  ny: 360
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.
  dir: "${dir_out}/${name_step_07}/lsm"
  fin_grdidx: "grdidx_river.bin"
[end]

[grid_system_latlon]
  nx: 720
  ny: 360
  west: -180
  east:  180
  south: -90
  north:  90
  is_south_to_north: .false.
[end]

[regridding]
  grid_coef: target
  grid_sort: target

  dir: "${dir_out_this}"
  fout_rt_sidx: "grid.bin", rec=1, endian=big
  fout_rt_tidx: "grid.bin", rec=2, endian=big
  fout_rt_area: "area.bin", endian=big
  fout_rt_coef: "coef.bin", endian=big
[end]

[options]
  old_files: remove

  earth_shape: sphere
  earth_r: ${earth_r}
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/regrid/main.exe ${f_conf}
