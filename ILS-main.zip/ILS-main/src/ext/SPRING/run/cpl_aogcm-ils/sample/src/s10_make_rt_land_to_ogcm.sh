#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
mkdir -p ${dir_set}/${name_step_10}

./s10c_lsm-river_to_ogcm_via_agcm.sh
./s10c_lsm-noriv-real_to_ogcm_via_agcm.sh
./s10c_lsm-noriv-virt_to_ogcm_via_agcm.sh
./s10c_rm-rivend_to_ogcm_via_agcm.sh
