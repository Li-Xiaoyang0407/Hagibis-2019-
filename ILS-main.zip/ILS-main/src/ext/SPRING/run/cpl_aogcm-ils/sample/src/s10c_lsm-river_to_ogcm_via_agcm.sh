#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_10}/make_rt_lsm-river_to_ogcm_via_agcm.conf"
dir_out_this="${dir_out}/${name_step_10}/rt_lsm-river_to_ogcm_via_agcm"

nij_rt_agcm_to_ogcm_ocean\
=`sed -n 3p ${dir_out}/${name_step_06}/rt_agcm_to_ogcm-ocean/report.txt | cut -d " " -f 2`
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[input_rt_agcm_to_ogcm_ocean]
  length: ${nij_rt_agcm_to_ogcm_ocean}
  dir: "${dir_out}/${name_step_06}/rt_agcm_to_ogcm-ocean"
  f_send: "grid.bin", rec=1
  f_recv: "grid.bin", rec=2
  f_area: "area.bin"
  f_coef: "coef.bin"
[end]

[input_agcm]
  nij: 32768
  dir: "${dir_out}/${name_step_05}"
  f_grdidx: "grdidx.bin"
  f_grdara: "grdara.bin"
  f_grdlon: "grdlonlat.bin", rec=1
  f_grdlat: "grdlonlat.bin", rec=2
  idx_miss: 0
[end]

[input_lsm]
  nij: 259200
  dir: "${dir_out}/${name_step_08}"
  f_grdidx: "grdidx_river.bin"
  f_grdara: "grdara_river.bin"
  f_grdlon: "grdlonlat_river.bin", rec=1
  f_grdlat: "grdlonlat_river.bin", rec=2
  idx_miss: -9999
[end]

[output_rt_lsm_to_agcm]
  grid_coef: none
  grid_sort: target

  dir: "${dir_out_this}"
  fout_rt_sidx: "grid.bin", rec=1, endian=big
  fout_rt_tidx: "grid.bin", rec=2, endian=big
  fout_rt_area: "area.bin", endian=big
  fout_rt_coef: "coef.bin", endian=big

  vrf_target_form: index
  fout_vrf_grdnum: "vrf/target_grdnum_fmt.bin"
[end]

[options]
  old_files: remove
  use_weighted_dist: .true.
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/ext/cpl_aogcm-ils_make_rt_for_ogcm/main.exe ${f_conf}
