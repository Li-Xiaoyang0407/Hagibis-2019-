#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
mkdir -p ${dir_set}/${name_step_11}

./s11c_io-bnd_to_lsm.sh
./s11c_io-met_to_lsm.sh

./s11c_agcm_to_lsm.sh
./s11c_lsm_to_agcm.sh

./s11c_lsm_to_io-rect.sh
./s11c_lsm_to_io-row.sh

./s11c_lsm_to_ogcm_via_agcm.sh
./s11c_lsm-noriv_to_ogcm_via_agcm.sh
