#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_11}/merge_rt_agcm_to_lsm.conf"
dir_out_this="${dir_out}/${name_step_11}/rt_agcm_to_lsm"

nij_river\
=`sed -n 25p ${dir_out}/${name_step_07}/report.txt | cut -d " " -f 2`
nij_noriv\
=`sed -n 36p ${dir_out}/${name_step_07}/report.txt | cut -d " " -f 2`
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[input]
  dir: "${dir_out}/${name_step_07}"

  length_rt: ${nij_river}
  f_rt_sidx: "rt_agcm_to_lsm-river/grid.bin", rec=1, endian=big
  f_rt_tidx: "rt_agcm_to_lsm-river/grid.bin", rec=2, endian=big
  f_rt_area: "rt_agcm_to_lsm-river/area.bin", endian=big
  f_rt_coef: "rt_agcm_to_lsm-river/coef.bin", endian=big

  length_rt: ${nij_noriv}
  f_rt_sidx: "rt_agcm_to_lsm-noriv/grid.bin", rec=1, endian=big
  f_rt_tidx: "rt_agcm_to_lsm-noriv/grid.bin", rec=2, endian=big
  f_rt_area: "rt_agcm_to_lsm-noriv/area.bin", endian=big
  f_rt_coef: "rt_agcm_to_lsm-noriv/coef.bin", endian=big
[end]

[output]
  grid_coef: target
  grid_sort: target
  opt_coef_sum_modify: 1.d0

  dir: "${dir_out_this}"
  f_rt_sidx: "grid.bin", rec=1, endian=big
  f_rt_tidx: "grid.bin", rec=2, endian=big
  f_rt_area: "area.bin", endian=big
  f_rt_coef: "coef.bin", endian=big
[end]

[options]
  old_files: remove
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/merge_regridding_tables/main.exe ${f_conf}
