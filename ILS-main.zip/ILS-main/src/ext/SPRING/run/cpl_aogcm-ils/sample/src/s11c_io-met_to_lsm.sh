#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_11}/merge_rt_io-met_to_lsm.conf"
dir_out_this="${dir_out}/${name_step_11}/rt_io-met_to_lsm"

nij_river\
=`sed -n 3p ${dir_out}/${name_step_09}/rt_io-met_to_lsm-river/report.txt | cut -d " " -f 2`
nij_noriv_real\
=`sed -n 3p ${dir_out}/${name_step_09}/rt_io-met_to_lsm-noriv-real/report.txt | cut -d " " -f 2`
nij_noriv_virt\
=`sed -n 3p ${dir_out}/${name_step_09}/rt_io-met_to_lsm-noriv-virt/report.txt | cut -d " " -f 2`
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[input]
  dir: "${dir_out}/${name_step_09}"

  length_rt: ${nij_river}
  f_rt_sidx: "rt_io-met_to_lsm-river/grid.bin", rec=1, endian=big
  f_rt_tidx: "rt_io-met_to_lsm-river/grid.bin", rec=2, endian=big
  f_rt_area: "rt_io-met_to_lsm-river/area.bin", endian=big
  f_rt_coef: "rt_io-met_to_lsm-river/coef.bin", eidian=big

  length_rt: ${nij_noriv_real}
  f_rt_sidx: "rt_io-met_to_lsm-noriv-real/grid.bin", rec=1, endian=big
  f_rt_tidx: "rt_io-met_to_lsm-noriv-real/grid.bin", rec=2, endian=big
  f_rt_area: "rt_io-met_to_lsm-noriv-real/area.bin", endian=big
  f_rt_coef: "rt_io-met_to_lsm-noriv-real/coef.bin", eidian=big

  length_rt: ${nij_noriv_virt}
  f_rt_sidx: "rt_io-met_to_lsm-noriv-virt/grid.bin", rec=1, endian=big
  f_rt_tidx: "rt_io-met_to_lsm-noriv-virt/grid.bin", rec=2, endian=big
  f_rt_area: "rt_io-met_to_lsm-noriv-virt/area.bin", endian=big
  f_rt_coef: "rt_io-met_to_lsm-noriv-virt/coef.bin", eidian=big
[end]

[output]
  grid_coef: target
  grid_sort: target
  opt_coef_sum_modify: 1.d0

  dir: "${dir_out_this}"
  f_rt_sidx: "grid.bin", rec=1, endian=big
  f_rt_tidx: "grid.bin", rec=2, endian=big
  f_rt_area: "area.bin", endian=big
  f_rt_coef: "coef.bin", endian=big
[end]

[options]
  old_files: remove
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/merge_regridding_tables/main.exe ${f_conf}
