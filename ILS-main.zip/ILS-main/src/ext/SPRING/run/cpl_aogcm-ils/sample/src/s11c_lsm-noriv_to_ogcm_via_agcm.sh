#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_11}/merge_rt_lsm_to_ogcm_via_agcm.conf"
dir_out_this="${dir_out}/${name_step_11}/rt_lsm_to_ogcm_via_agcm"

nij_river\
=`sed -n 3p ${dir_out}/${name_step_10}/rt_lsm-river_to_ogcm_via_agcm/report.txt | cut -d " " -f 2`
nij_noriv_real\
=`sed -n 3p ${dir_out}/${name_step_10}/rt_lsm-noriv-real_to_ogcm_via_agcm/report.txt | cut -d " " -f 2`
nij_noriv_virt\
=`sed -n 3p ${dir_out}/${name_step_10}/rt_lsm-noriv-virt_to_ogcm_via_agcm/report.txt | cut -d " " -f 2`
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[input]
  length_rt: ${nij_noriv_real}
  dir: "${dir_out}/${name_step_10}/rt_lsm-noriv-real_to_ogcm_via_agcm"
  f_rt_sidx: "grid.bin", rec=1, endian=big
  f_rt_tidx: "grid.bin", rec=2, endian=big
  f_rt_area: "area.bin", endian=big
  f_rt_coef: "coef.bin", endian=big

  length_rt: ${nij_noriv_virt}
  dir: "${dir_out}/${name_step_10}/rt_lsm-noriv-virt_to_ogcm_via_agcm"
  f_rt_sidx: "grid.bin", rec=1, endian=big
  f_rt_tidx: "grid.bin", rec=2, endian=big
  f_rt_area: "area.bin", endian=big
  f_rt_coef: "coef.bin", endian=big

  opt_idx_duplication: sum
[end]

[output]
  grid_coef: none
  grid_sort: target

  dir: "${dir_out_this}"
  f_rt_sidx: "grid.bin", rec=1, endian=big
  f_rt_tidx: "grid.bin", rec=2, endian=big
  f_rt_area: "area.bin", endian=big
  f_rt_coef: "coef.bin", endian=big
[end]

[options]
  old_files: remove
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/merge_regridding_tables/main.exe ${f_conf}
