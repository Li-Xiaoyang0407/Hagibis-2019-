#!/bin/bash
set -e
set -x
#===============================================================
#
#===============================================================
f_conf="${dir_set}/${name_step_11}/merge_rt_lsm_to_agcm.conf"
dir_out_this="${dir_out}/${name_step_11}/rt_lsm_to_agcm"

nij_river\
=`sed -n 3p ${dir_out}/${name_step_07}/report.txt | cut -d " " -f 2`
nij_noriv\
=`sed -n 14p ${dir_out}/${name_step_07}/report.txt | cut -d " " -f 2`
#===============================================================
#
#===============================================================
cat << EOF > ${f_conf}
#
path_report: "${dir_out_this}/report.txt"

[input]
  dir: "${dir_out}/${name_step_07}"

  # river
  length_rt: ${nij_river}
  f_rt_sidx: "rt_lsm-river_to_agcm/grid.bin", rec=1, endian=big
  f_rt_tidx: "rt_lsm-river_to_agcm/grid.bin", rec=2, endian=big
  f_rt_area: "rt_lsm-river_to_agcm/area.bin", endian=big
  f_rt_coef: "rt_lsm-river_to_agcm/coef.bin", endian=big

  # noriv
  length_rt: ${nij_noriv}
  f_rt_sidx: "rt_lsm-noriv_to_agcm/grid.bin", rec=1, endian=big
  f_rt_tidx: "rt_lsm-noriv_to_agcm/grid.bin", rec=2, endian=big
  f_rt_area: "rt_lsm-noriv_to_agcm/area.bin", endian=big
  f_rt_coef: "rt_lsm-noriv_to_agcm/coef.bin", endian=big

  opt_idx_duplication: stop
[end]

[output]
  grid_coef: target
  grid_sort: target
  opt_coef_sum_modify: 1.d0

  dir: "${dir_out_this}"
  f_rt_sidx: "grid.bin", rec=1, endian=big
  f_rt_tidx: "grid.bin", rec=2, endian=big
  f_rt_area: "area.bin", endian=big
  f_rt_coef: "coef.bin", endian=big
[end]

[options]
  old_files: remove
[end]
EOF
#===============================================================
#
#===============================================================
${dir_spring}/bin/std/merge_regridding_tables/main.exe ${f_conf}
