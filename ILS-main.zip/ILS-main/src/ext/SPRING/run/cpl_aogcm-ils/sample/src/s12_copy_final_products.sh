#!/bin/bash
set -e
set -x

cd ${dir_out}

rm -rf ${name_step_12}
mkdir -p ${name_step_12}
#===============================================================
# Regridding tables
#===============================================================
cp -r ${name_step_11}/rt_agcm_to_lsm ${name_step_12}/.

# agcm -> rm (dummy)
#cp -r

cp -r ${name_step_11}/rt_lsm_to_agcm ${name_step_12}/.

cp -r ${name_step_07}/rt_lsm-noriv_to_agcm ${name_step_12}/.
head -n 22 ${name_step_07}/report.txt | tail -n +12 > ${name_step_12}/rt_lsm-noriv_to_agcm/report.txt

cp -r ${name_step_09}/rt_lsm-river_to_rm ${name_step_12}/.

cp -r ${name_step_09}/rt_rm_to_lsm-river ${name_step_12}/.

cp -r ${name_step_11}/rt_lsm_to_ogcm_via_agcm ${name_step_12}/.

cp -r ${name_step_10}/rt_rm-rivend_to_ogcm_via_agcm ${name_step_12}/.

cp -r ${name_step_11}/rt_io-bnd_to_lsm ${name_step_12}/.

cp -r ${name_step_11}/rt_io-met_to_lsm ${name_step_12}/.

cp -r ${name_step_11}/rt_lsm_to_io-rect ${name_step_12}/.

cp -r ${name_step_11}/rt_lsm_to_io-row ${name_step_12}/.

cp -r ${name_step_09}/rt_rm_to_io-row ${name_step_12}/.
#===============================================================
# Grid data
#===============================================================
cp -r ${name_step_03} ${name_step_12}/rm

cp -r ${name_step_07}/lsm ${name_step_12}/.

cp -r ${name_step_07}/agcm ${name_step_12}/.
