import configparser
import numpy as np

class ILS_Config:
    def __init__(self, path_cfg):
        self.config = configparser.ConfigParser()
        self.config.read(path_cfg)

    def get_str(self, section, item):
        return self.config.get(section, item)

    def get_list(self, section, item):
        return self.config.get(section, item).strip().split()

    def get_int(self, section, item):
        return int(self.config.get(section, item))

    def get_float(self, section, item):
        return float(self.config.get(section, item))

    def write_log(self, section):
        print("[ILS boundary tool] %s"%section)
        for item in self.config.items(section):
            print("    %s = %s"%(item[0], item[1]))

