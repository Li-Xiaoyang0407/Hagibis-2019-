import numpy as np

def get_bounds_raster(
        west_tile, east_tile, north_tile, south_tile,
        west_raster, east_raster, north_raster, south_raster, 
        ndx_1deg, ndy_1deg, ndx, ndy):

    if east_tile <= west_raster or east_raster <= west_tile or \
       north_tile <= south_raster or north_raster <= south_tile:
        return

    dwest = int(np.floor(west_tile))
    deast = int(np.ceil(east_tile))
    dnorth = int(np.ceil(north_tile))
    dsouth = int(np.floor(south_tile))

    dxi = max(int(np.floor(dwest - west_raster)) * ndx_1deg + 1, 1)
    dxf = min(int(np.ceil(deast - west_raster)) * ndx_1deg, ndx)
    dyi = max(int(np.floor(north_raster - dnorth)) * ndy_1deg + 1, 1)
    dyf = min(int(np.ceil(north_raster - dsouth)) * ndy_1deg, ndy)

    return dwest, deast, dnorth, dsouth, dxi, dxf, dyi, dyf
