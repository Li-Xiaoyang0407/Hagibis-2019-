import numpy as np

def get_tile_lat(ity, nty):
    size_tile = int(180 / nty)
    north = 90 - (ity-1)*size_tile
    south = 90 - ity*size_tile

    if north > 0:
        tile_lat = 'N{:02d}'.format(north)
    else:
        tile_lat = 'S{:02d}'.format(-north)

    return north, south, tile_lat

def get_tile_lon(itx, ntx):
    size_tile = int(360 / ntx)
    west = -180 + (itx-1)*size_tile
    east = -180 + itx*size_tile

    if west >= 0:
        tile_lon = 'E{:03d}'.format(west)
    else:
        tile_lon = 'W{:03d}'.format(-west)

    return west, east, tile_lon
