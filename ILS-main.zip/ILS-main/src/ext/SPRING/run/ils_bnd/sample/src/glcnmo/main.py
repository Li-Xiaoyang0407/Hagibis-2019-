import glcnmo.make_conf

def make_conf_glcnmo(config):
    config.write_log('glcnmo')
    glcnmo.make_conf.main(config)
