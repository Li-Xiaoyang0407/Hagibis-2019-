import gtopo30.make_conf

def make_conf_gtopo30(config):
    config.write_log('gtopo30')
    gtopo30.make_conf.main(config)
