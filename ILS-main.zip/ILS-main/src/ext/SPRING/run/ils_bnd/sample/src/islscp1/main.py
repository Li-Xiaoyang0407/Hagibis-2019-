import islscp1.make_conf

def make_conf_islscp1(config):
    config.write_log('islscp1')
    islscp1.make_conf.main(config)
