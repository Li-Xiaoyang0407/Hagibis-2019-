#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import resource
import sys
from common.ils_error import ILS_Error
from common.ils_config import ILS_Config
from glcnmo.main import make_conf_glcnmo
from gtopo30.main import make_conf_gtopo30
from islscp1.main import make_conf_islscp1
from modis.main import make_conf_modis

def main(path_cfg):
    config = ILS_Config(path_cfg)
    config.write_log('make_conf')
    list_name_data = get_data_names(config)

    for name_data in list_name_data:
        eval('make_conf_%s'%name_data)(config)

    return


def get_data_names(config):
    list_name_data = config.get_list('make_conf', 'list_name_data')

    list_name_data_all = [
        'glcnmo',
        'gtopo30',
        'islscp1',
        'modis',
    ]

    for nam in list_name_data:
        if nam not in list_name_data:
            raise ILS_Error('"{}" is not in the list of data name [{}]'\
                            .format(nam, ', '.join(list_name_data_all)))

    return list_name_data


if __name__ == '__main__':
    argvs = sys.argv
    if len(argvs) == 1:
        path_cfg = 'make_conf.cfg'
    elif len(argvs) == 2:
        path_cfg = argvs[1]
    else:
        raise ILS_Error("Usage: python %s [config file]" % argvs[0])

    main(path_cfg)
