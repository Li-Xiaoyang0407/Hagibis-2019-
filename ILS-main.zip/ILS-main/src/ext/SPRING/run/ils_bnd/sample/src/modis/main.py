import modis.make_conf

def make_conf_modis(config):
    config.write_log('modis')
    modis.make_conf.main(config)
