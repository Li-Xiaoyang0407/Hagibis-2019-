import os
import sys
import numpy as np
from common.tile import get_tile_lat, get_tile_lon
from common.raster import get_bounds_raster


def main(config):
    config_key = 'modis'

    d = {}

    # Get params. common for all data
    list_type_land = config.get_list(config_key, 'list_type_land')
    d['dir_set'] = config.get_str(config_key, 'dir_set')
    d['dir_out'] = config.get_str(config_key, 'dir_out')
    fmt_f_rstidx = config.get_str(config_key, 'fmt_f_rstidx')
    fmt_f_grdidx = config.get_str(config_key, 'fmt_f_grdidx')
    fmt_f_grdwgt = config.get_str(config_key, 'fmt_f_grdwgt')
    d['ndx'] = config.get_int(config_key, 'nx_raster')
    d['ndy'] = config.get_int(config_key, 'ny_raster')
    d['ncx'] = config.get_int(config_key, 'nx_grid')
    d['ncy'] = config.get_int(config_key, 'ny_grid')
    d['west_mat'] = config.get_float(config_key, 'west')
    d['east_mat'] = config.get_float(config_key, 'east')
    d['south_mat'] = config.get_float(config_key, 'south')
    d['north_mat'] = config.get_float(config_key, 'north')

    d['ndx_1deg'] = int(d['ndx'] / (d['east_mat'] - d['west_mat']))
    d['ndy_1deg'] = int(d['ndy'] / (d['north_mat'] - d['south_mat']))

    # Set params. specific to this data
    d['name_data'] = 'modis'
    d['ntx'] = 36
    d['nty'] = 18
    d['dir_modis_coords'] = config.get_str(config_key, 'dir_modis_coords')
    d['modis_coord_miss'] = -999.0

    d['dir_set_this'] = '{dir_set}/regrid/{name_data}'.format(**d)
    d['dir_out_this'] = '{dir_out}/{name_data}'.format(**d)

    if not os.path.isdir(d['dir_set_this']):
        print('Creating the directory {dir_set_this}'.format(**d))
        os.makedirs(d['dir_set_this'])

    if not os.path.isdir(d['dir_out_this']):
        print('Creating the directory {dir_out_this}'.format(**d))
        os.makedirs(d['dir_out_this'])


    path_list_tile = os.path.join(d['dir_modis_coords'], 'tiles.txt')
    list_tiles = [line.strip() for line in open(path_list_tile,'r').readlines()]

    # Make a list of info. of tiles
    list_info_tiles = []
    for tile in list_tiles:
        list_info_tiles.append(get_info_tile(tile, d))

    # Make a file of list of tile names
    path_list_tiles = os.path.join(d['dir_out_this'], 'all_tiles.txt')
    f_list_tiles = open(path_list_tiles, 'w')
    for info_tile in list_info_tiles:
        if info_tile['stat'] != 0: continue
        f_list_tiles.write(info_tile['tile']+'\n')
    f_list_tiles.close()

    # Make setting files
    for type_land in list_type_land:
        d['type_land'] = type_land
        d['f_rstidx'] = fmt_f_rstidx.format(**d)
        d['f_grdidx'] = fmt_f_grdidx.format(**d)
        d['f_grdwgt'] = fmt_f_grdwgt.format(**d)

        for info_tile in list_info_tiles:
            if info_tile['stat'] != 0: continue
            make_conf(info_tile, d)


def get_info_tile(tile, d):
    west_tile, east_tile, north_tile, south_tile \
        = get_bbox_modis(d['dir_modis_coords'], d['modis_coord_miss'], tile)

    try:
        stat = 0
        dwest, deast, dnorth, dsouth, dxi, dxf, dyi, dyf \
            = get_bounds_raster(
                  west_tile, east_tile, north_tile, south_tile,
                  d['west_mat'], d['east_mat'], d['north_mat'], d['south_mat'],
                  d['ndx_1deg'], d['ndy_1deg'],
                  d['ndx'], d['ndy'])
        print(tile)
        print('  Lon: {:8.3f} ~ {:8.3f} ({:4d} ~ {:4d}, {:5d}~{:5d})'\
              .format(west_tile, east_tile, dwest, deast, dxi, dxf))
        print('  Lat: {:8.3f} ~ {:8.3f} ({:4d} ~ {:4d}, {:5d}~{:5d})'\
              .format(north_tile, south_tile, dnorth, dsouth, dyi, dyf))

    except TypeError:
        stat = 1
        dwest, deast, dnorth, dsouth = 0, 0, 0, 0
        dxi, dxf, dyi, dyf = 0, 0, 0, 0
        print('{} Out of range. Lon: {:8.3f} ~ {:8.3f}, Lat: {:8.3f} ~ {:8.3f}'\
              .format(tile, west_tile, east_tile, north_tile, south_tile))

    info_tile = {
        'stat': stat,
        'tile': tile,
        'north_tile': north_tile, 
        'south_tile': south_tile, 
        'west_tile': west_tile,
        'east_tile': east_tile,
        'dxi': dxi,
        'dxf': dxf, 
        'dyi': dyi,
        'dyf': dyf,
    }

    return info_tile


def make_conf(info_tile, d):

    path_conf = '{dir_set_this}/{tile}_{type_land}.conf'\
                .format(**d, **info_tile)

    s = ''
    s += '\
#\n\
path_report: "{dir_out_this}/report_regrid/{tile}_{type_land}.txt"\n\
\n\
[grid_system_polygon]\n\
  np: 4\n\
  nij: 1440000\n\
  dir: "{dir_modis_coords}"\n\
  f_lon_vertex: "lon_{tile}.bin"\n\
  f_lat_vertex: "lat_{tile}.bin"\n\
  coord_unit: degree\n\
  coord_miss: -999.d0\n\
  arc_parallel: .true.\n\
[end]\n\
\n\
[grid_system_raster]\n\
  nx: {ndx}\n\
  ny: {ndy}\n\
  xi: {dxi}\n\
  xf: {dxf}\n\
  yi: {dyi}\n\
  yf: {dyf}\n\
  west: {west_mat}\n\
  east: {east_mat}\n\
  south: {south_mat}\n\
  north: {north_mat}\n\
  fin_rstidx: "{f_rstidx}"\n\
'
    if d['f_grdwgt'] != '':
        s += '\
  fin_grdidx: "{f_grdidx}"\n\
  fin_grdwgt: "{f_grdwgt}"\n\
  in_grid_sz: {ncx}, {ncy}\n\
'

    s += '\
  idx_miss: -9999\n\
  is_south_to_north: .false.\n\
[end]\n\
\n\
[regridding]\n\
  dir: "{dir_out_this}"\n\
  fout_rt_sidx: "mapping_table_idx_{tile}_{type_land}.bin", int4, 1, big\n\
  fout_rt_tidx: "mapping_table_idx_{tile}_{type_land}.bin", int4, 2, big\n\
  fout_rt_area: "mapping_table_area_{tile}_{type_land}.bin", dble, 1, big\n\
  fout_rt_coef: "mapping_table_coef_{tile}_{type_land}.bin", dble, 1, big\n\
\n\
  opt_coef_zero_negative: -1d-10\n\
  opt_coef_zero_positive:  1d-10\n\
\n\
  allow_empty: .true.\n\
\n\
#  dir: "{dir_out_this}/vrf"\n\
#  vrf_source_form: auto\n\
#  fout_vrf_grdara_true: "source_val_{tile}_{type_land}.bin", rec=1\n\
#  fout_vrf_grdara_rt  : "source_val_{tile}_{type_land}.bin", rec=2\n\
#  fout_vrf_rerr_grdara: "source_val_{tile}_{type_land}.bin", rec=3\n\
\n\
#  vrf_target_form: index\n\
#  fout_vrf_grdara_true: "target_val_{tile}_{type_land}.bin", rec=1\n\
#  fout_vrf_grdara_rt  : "target_val_{tile}_{type_land}.bin", rec=2\n\
#  fout_vrf_rerr_grdara: "target_val_{tile}_{type_land}.bin", rec=3\n\
[end]\n\
\n\
[options]\n\
  old_files: remove\n\
  remove_intermediates: .true.\n\
[end]\n\
'

    s = s.format(
        **d, **info_tile,
    )

    f = open(path_conf, 'w')
    f.write(s)
    f.close()



def get_bbox_modis(dir_coords, coord_miss, tile):
    f_lons = os.path.join(dir_coords, 'lon_{}.bin'.format(tile))
    f_lats = os.path.join(dir_coords, 'lat_{}.bin'.format(tile))

    lons = np.fromfile(f_lons).reshape(4,1200,1200)
    lats = np.fromfile(f_lats).reshape(4,1200,1200)

    west = lons[lons != coord_miss].min()
    east = lons[lons != coord_miss].max()
    north = lats[lats != coord_miss].max()
    south = lats[lats != coord_miss].min()

    return west, east, north, south
