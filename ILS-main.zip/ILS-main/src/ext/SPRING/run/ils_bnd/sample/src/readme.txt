for data in glcnmo gtopo30 islscp1 modis; do
  qsub -v data=${data} -N ils_bnd_regrid_${data} s01_regrid.sh
done
