#!/bin/bash
#PBS -N ils_bnd_s01_regrid
set -e

cd ${PBS_O_WORKDIR}

# Environmental variable
name_data=${data}

# Kinds of land
list_type_land="river noriv-real noriv-virt"

# Directories
dir_set="../set/regrid/${name_data}"
program="../../../../bin/std/regrid/main.exe"
#===============================================================
#
#===============================================================
for type_land in ${list_type_land}; do
  for f_conf in `ls --color=never ${dir_set}/*_${type_land}.conf`; do
    ${program} ${f_conf}
  done
done
