#!/bin/bash
#PBS -N ils_bnd_s02_merge
set -e

cd ${PBS_O_WORKDIR}

# Environmental variable
name_data=${data}

# Directories
dir_rt="../out/${name_data}"
dir_set="../set/merge/${name_data}"
program="../../../../bin/std/merge_regridding_tables/main.exe"

[ ! -d ${dir_set} ] && mkdir -p ${dir_set}
#===============================================================
#
#===============================================================
path_list_tiles="${dir_rt}/all_tiles.txt"
cat ${path_list_tiles} | while read tile; do

  nij_noriv_real=0
  nij_noriv_virt=0

  for type_land in noriv-real noriv-virt; do
    path_report="${dir_rt}/report_regrid/${tile}_${type_land}.txt"

    filesize=`ls -l ${path_report} | cut -d ' ' -f 5`
    filesize=`eval "echo ${filesize}"`
    [ ${filesize} -eq 0 ] && continue

    nij=`sed -n 3p ${path_report} | cut -d ' ' -f 2`
    if [ ${type_land} = "noriv-real" ]; then
      nij_noriv_real=${nij}
    else
      nij_noriv_virt=${nij}
    fi
  done

  printf "tile %10s nij noriv-real: %10d, noriv-virt: %10d\n" \
         ${tile} ${nij_noriv_real} ${nij_noriv_virt}


  if [ ${nij_noriv_real} -eq 0 -a ${nij_noriv_virt} -eq 0 ]; then
    continue
  elif [ ${nij_noriv_real} -ne 0 -a ${nij_noriv_virt} -eq 0 ]; then
    cp ${dir_rt}/mapping_table_idx_${tile}_noriv-real.bin \
       ${dir_rt}/mapping_table_idx_${tile}_noriv.bin
    cp ${dir_rt}/mapping_table_area_${tile}_noriv-real.bin \
       ${dir_rt}/mapping_table_area_${tile}_noriv.bin
    cp ${dir_rt}/mapping_table_coef_${tile}_noriv-real.bin \
       ${dir_rt}/mapping_table_coef_${tile}_noriv.bin
  elif [ ${nij_noriv_real} -eq 0 -a ${nij_noriv_virt} -ne 0 ]; then
    cp ${dir_rt}/mapping_table_idx_${tile}_noriv-virt.bin \
       ${dir_rt}/mapping_table_idx_${tile}_noriv.bin
    cp ${dir_rt}/mapping_table_area_${tile}_noriv-virt.bin \
       ${dir_rt}/mapping_table_area_${tile}_noriv.bin
    cp ${dir_rt}/mapping_table_coef_${tile}_noriv-virt.bin \
       ${dir_rt}/mapping_table_coef_${tile}_noriv.bin
  else

    f_conf="${dir_set}/${tile}_noriv.conf"

    cat << EOF > ${f_conf}
#
path_report: "${dir_rt}/report_merge/${tile}_noriv.txt"

[input]
  dir: "${dir_rt}"

  length_rt: ${nij_noriv_real}
  f_rt_sidx: "mapping_table_idx_${tile}_noriv-real.bin", rec=1, endian=big
  f_rt_tidx: "mapping_table_idx_${tile}_noriv-real.bin", rec=2, endian=big
  f_rt_area: "mapping_table_area_${tile}_noriv-real.bin", endian=big
  f_rt_coef: "mapping_table_coef_${tile}_noriv-real.bin", endian=big

  length_rt: ${nij_noriv_virt}
  f_rt_sidx: "mapping_table_idx_${tile}_noriv-virt.bin", rec=1, endian=big
  f_rt_tidx: "mapping_table_idx_${tile}_noriv-virt.bin", rec=2, endian=big
  f_rt_area: "mapping_table_area_${tile}_noriv-virt.bin", endian=big
  f_rt_coef: "mapping_table_coef_${tile}_noriv-virt.bin", endian=big

  opt_idx_duplication: sum
[end]

[output]
  dir: "${dir_rt}"
  f_rt_sidx: "mapping_table_idx_${tile}_noriv.bin", rec=1, endian=big
  f_rt_tidx: "mapping_table_idx_${tile}_noriv.bin", rec=2, endian=big
  f_rt_area: "mapping_table_area_${tile}_noriv.bin", endian=big
  f_rt_coef: "mapping_table_coef_${tile}_noriv.bin", endian=big

  grid_coef: target
  grid_sort: target

  opt_coef_sum_modify: 1.d0

  opt_coef_zero_positive:  1.d-10
  opt_coef_zero_negative: -1.d-10
[end]

[options]
  old_files: remove
  remove_intermediates: .true.
[end]
EOF

  ${program} ${f_conf}

  fi
done
