import os
import sys
import numpy as np
import netCDF4

args = sys.argv
fin_nc = args[1]
dirout_bin = args[2]

fout_coord = os.path.join(dirout_bin,'xyz.bin')
fout_TPW = os.path.join(dirout_bin,'val_TPW.bin')
fout_CFR = os.path.join(dirout_bin,'val_CFR.bin')
fout_TPO = os.path.join(dirout_bin,'val_TPO.bin')
fout_A1 = os.path.join(dirout_bin,'val_A1.bin')
fout_A2 = os.path.join(dirout_bin,'val_A2.bin')

nc = netCDF4.Dataset(fin_nc,'r')

x = nc['coord'][:].data[0]
y = nc['coord'][:].data[1]
z = nc['coord'][:].data[2]

print('Num. of nodes: {}'.format(x.size))

nij = 0
nk = 0
for key in ['connect1', 'connect2', 'connect3']:
    if key not in nc.variables.keys(): continue
    nij += nc[key].shape[0]
    nk = max(nk,nc[key].shape[1])
print('Num. of grids: {}'.format(nij))
print('Max. num. of vertices: {}'.format(nk))

px = np.ones((nij,nk)) * -1e-20
py = np.ones((nij,nk)) * -1e-20
pz = np.ones((nij,nk)) * -1e-20
nij = 0
for key in ['connect1', 'connect2', 'connect3']:
    if key not in nc.variables.keys(): continue
    mij, mk = nc[key].shape
    px[nij:nij+mij,:mk] = nc['coord'][:].data[0,nc[key][:]-1]
    py[nij:nij+mij,:mk] = nc['coord'][:].data[1,nc[key][:]-1]
    pz[nij:nij+mij,:mk] = nc['coord'][:].data[2,nc[key][:]-1]
    nij += mij

np.r_[px,py,pz].reshape(3,px.shape[0],px.shape[1]).tofile(fout_coord)

nc['TotalPrecipWater'][:].data.tofile(fout_TPW)
nc['CloudFraction'][:].data.tofile(fout_CFR)
nc['Topography'][:].data.tofile(fout_TPO)
nc['AnalyticalFun1'][:].data.tofile(fout_A1)
nc['AnalyticalFun2'][:].data.tofile(fout_A2)
