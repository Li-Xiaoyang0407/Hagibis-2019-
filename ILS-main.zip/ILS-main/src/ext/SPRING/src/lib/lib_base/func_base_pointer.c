#include <stdio.h>

void c_address_( double *arr){
  printf("arr: %p\n", &arr);
}
