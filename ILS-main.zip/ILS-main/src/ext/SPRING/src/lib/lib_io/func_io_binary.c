# include <stdio.h>
# include <stdlib.h>
# include <stdint.h>
# include <byteswap.h>
# include <string.h>
/*============================================================*/
/*                                                            */
/*============================================================*/
FILE *fp;
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fopen_( char *path, int *len_path, 
               char *mode, int *len_mode, int *stat ){
  *stat = 0;

  int i;

  char p[*len_path+1];
  for( i = 0; i < *len_path; i++ ){
    p[i] = path[i];
  }
  p[*len_path] = '\0';

  char m[*len_mode+1];
  for( i = 0; i < *len_mode; i++ ){
    m[i] = mode[i];
  }
  m[*len_mode] = '\0';

  fp = fopen(p, m);

  if( fp == NULL ){
    *stat = 1;
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fclose_( int *stat ){
  *stat = 0;

  if( fclose(fp) == EOF ){
    *stat = 1;
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fseek_set_( long *offset, int *stat ){
  *stat = 0;
  if( *offset != 0 ){
    if( fseek( fp, *offset, SEEK_SET ) != 0 ){
      *stat = 1;
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fseek_cur_( long *offset, int *stat ){
  *stat = 0;
  if( *offset != 0 ){
    if( fseek( fp, *offset, SEEK_CUR ) != 0 ){
      *stat = 1;
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fseek_end_( long *offset, int *stat ){
  *stat = 0;
  if( fseek( fp, *offset, SEEK_END ) != 0 ){
    *stat = 1;
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fread_int1_( char *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( fread( d, sizeof(d[0]), *size, fp ) != *size ){
    *stat = 1;
    return;
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fread_int2_( short *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( fread( d, sizeof(d[0]), *size, fp ) != *size ){
    *stat = 1;
    return;
  }

  if( *big ){
    long i;
    for( i = 0; i < *size; i++ ){
      d[i] = bswap_16(d[i]);
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fread_int4_( int *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( fread( d, sizeof(d[0]), *size, fp ) != *size ){
    *stat = 1;
    return;
  }

  if( *big ){
    long i;
    for( i = 0; i < *size; i++ ){
      d[i] = bswap_32(d[i]);
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fread_int8_( long *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( fread( d, sizeof(d[0]), *size, fp ) != *size ){
    *stat = 1;
  }

  if( *big ){
    long i;
    for( i = 0; i < *size; i++ ){
      d[i] = bswap_64(d[i]);
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fread_real_( float *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( fread( d, sizeof(d[0]), *size, fp ) != *size ){
    *stat = 1;
    return;
  }

  if( *big ){
    uint32_t uint32;
    long i;
    for( i = 0; i < *size; i++ ){
      memcpy(&uint32, &d[i], sizeof(d[i]));
      uint32 = bswap_32(uint32);
      memcpy(&d[i], &uint32, sizeof(d[i]));
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fread_dble_( double *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( fread( d, sizeof(d[0]), *size, fp ) != *size ){
    *stat = 1;
    return;
  }

  if( *big ){
    uint64_t uint64;
    long i;
    for( i = 0; i < *size; i++ ){
      memcpy(&uint64, &d[i], sizeof(d[i]));
      uint64 = bswap_64(uint64);
      memcpy(&d[i], &uint64, sizeof(d[i]));
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fwrite_int1_( char *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( fwrite( d, sizeof(d[0]), *size, fp ) != *size ){
    *stat = 1;
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fwrite_int2_( short *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( *big ){
    short *d_swap = malloc(*size * sizeof(d_swap[0]));
    long i;
    for( i = 0; i < *size; i++ ){
      d_swap[i] = bswap_16(d[i]);
    }
    if( fwrite( d_swap, sizeof(d_swap[0]), *size, fp ) != *size ){
      *stat = 1;
    }
    free(d_swap);
  } else {
    if( fwrite( d, sizeof(d[0]), *size, fp ) != *size ){
      *stat = 1;
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fwrite_int4_( int *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( *big ){
    int *d_swap = malloc(*size * sizeof(d_swap[0]));
    long i;
    for( i = 0; i < *size; i++ ){
      d_swap[i] = bswap_32(d[i]);
    }
    if( fwrite(d_swap, sizeof(d_swap[0]), *size, fp ) != *size ){
      *stat = 1;
    }
    free(d_swap);
  } else {
    if( fwrite( d, sizeof(d[0]), *size, fp ) != *size ){
      *stat = 1;
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fwrite_int8_( long *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( *big ){
    long *d_swap = malloc(*size * sizeof(d_swap[0]));
    long i;
    for( i = 0; i < *size; i++ ){
      d_swap[i] = bswap_64(d[i]);
    }
    if( fwrite( d_swap, sizeof(d_swap[0]), *size, fp ) != *size ){
      *stat = 1;
    }
    free(d_swap);
  } else {
    if( fwrite( d, sizeof(d[0]), *size, fp ) != *size ){
      *stat = 1;
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fwrite_real_( float *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( *big ){
    float *d_swap = malloc(*size * sizeof(d_swap[0]));
    uint32_t uint32;
    long i;
    for( i = 0; i < *size; i++ ){
      memcpy(&uint32, &d[i], sizeof(d[i]));
      uint32 = bswap_32(uint32);
      memcpy(&d_swap[i], &uint32, sizeof(d_swap[i]));
    }
    if( fwrite( d_swap, sizeof(d_swap[0]), *size, fp ) != *size ){
      *stat = 1;
    }
    free(d_swap);
  } else {
    if( fwrite( d, sizeof(d[0]), *size, fp ) != *size ){
      *stat = 1;
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fwrite_dble_( double *d, long *size, int *big, int *stat ){
  *stat = 0;

  if( *big ){
    double *d_swap = malloc(*size * sizeof(d_swap[0]));
    uint64_t uint64;
    long i;
    for( i = 0; i < *size; i++ ){
      memcpy(&uint64, &d[i], sizeof(d[i]));
      uint64 = bswap_64(uint64);
      memcpy(&d_swap[i], &uint64, sizeof(d[i]));
    }
    if( fwrite( d_swap, sizeof(d[0]), *size, fp ) != *size ){
      *stat = 1;
    }
    free(d_swap);
  } else {
    if( fwrite( d, sizeof(d[0]), *size, fp ) != *size ){
      *stat = 1;
    }
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fwrite_fill_int4_( int *d, long *size, int *big, int *stat ){
  *stat = 0;

  int d_out;

  if( *big ){
    uint32_t uint32;
    memcpy(&uint32, &d, sizeof(*d));
    uint32 = bswap_32(uint32);
    memcpy(&d_out, &uint32, sizeof(d_out));
  } else {
    d_out = *d;
  }

  long i;
  for( i = 0; i < *size; i++ ){
    fwrite( &d_out, sizeof(d_out), 1, fp );
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
void c_fwrite_fill_real_( float *d, long *size, int *big, int *stat ){
  *stat = 0;

  float d_out;

  if( *big ){
    uint32_t uint32;
    memcpy(&uint32, &d, sizeof(*d));
    uint32 = bswap_32(uint32);
    memcpy(&d_out, &uint32, sizeof(d_out));
  } else {
    d_out = *d;
  }

  long i;
  for( i = 0; i < *size; i++ ){
    fwrite( &d_out, sizeof(d_out), 1, fp );
  }
}
/*============================================================*/
/*                                                            */
/*============================================================*/
