 # README 
This readme describes the MATSIRO emulator. MATSIRO emulator contains three parts: basic functions (located in ``/src/basic`` directory), stand-alone emulator with the parameter optimization capacity (located in ``src/emul`` directory) and an emulator coupled with ILS (MATSIRO replaced with the emulator) (located in ``src/emul_coupled`` directory). 

> [!CAUTION]
> The time labels of output files for checking (input forcings and parameters) are shifted one day later compared to the original input. 

# CODE RESTRICTIONS

## General
- The stand-alone emulator is restricted to the standard 0.5 degree code resolution. No such restriction exists for the coupled emulator.
- The emulator is restricted to the standard calendard. It is not clear how it can be used before the adoption of the gregorian calendar
- Only certain processor configurations (see the OTHER section below) are allowed for the stand alone emulator. No such restrictions exist for the coupled emulator. 
- It runs with the ifort compiler. It can not use gfortran compilers

 ## For the coupled emulator
 - CaMa-Flood must use the restart option

# OBTAINING THE EMULATOR CODE
The code has been incorporated as a branch "ILS_emul" of the ILS repository. Once you download ILS, the MATSIRO emulator is available by checking out this branch 

# INSTALLATION
> [!NOTE]
> The set-up is different depending on whether the emulator is used as a stand-alone or coupled version. In order to switch between the two versions, it can be useful to place lines with paths to both sets of dependencies and libraries in the confuguration file `.bashrc`, and to selectively comment/uncomment them. 

## Dependencies (stand-alone emulator)
 - Ifort
 - MPI library
 - netCDF-Fortran, compiled with parallel flags
 - PLplot Fortran library
       After installing PLplot please add the relevant library directory
       to the LD_LIBRARY_PATH, and the relevant pkgconfig directory to the
       PKG_CONFIG_PATH environmental variable. 
- (Optional) yEd => To visualize the program structure in the file `flow.graphml`

## Dependencies (coupled emulator)
- Ifort
- MPI library
- netCDF-Fortran(standard, not parallel)
- Add the following line to the `.bashrc` configuration file:
  ```export ILS_SYS=[system name]```
- (Optional) yEd => To visualize the program structure in the file `flow.graphml`
  
Note that these settings are the same or similar to the ILS. 

Dependencies -- specific procedure for Isotope 3
------------------------
Note: on the isotope3 server, it is possible to use my directories for the
libraries, if you don't want to install them on your own. All these libraries
have to be used as we are using static libraries. Please add the
following code to your .bashrc file. 

On Isotope3, stand-alone emulator runs with the following configuration: Ifort 19.0.3, MPI library mpich3.2,
netCDF-Fortran 4.6.0, compiled with parallel flags, and PLplot 5.11.0 Fortran library. The coupled emulator runs with the following setup: Ifort 19.0.3, MPI library openmpi2.1.6, and netCDF-Fortran 4.7.0 (standard, not parallel). ILS_SYS must be "isotope3". 

```
# #==========================================================
# #NETCDF STAND-ALONE PARALLEL EMULATOR SETTINGS. 
# #To be used with MPI settings 3u
# #==========================================================
# # HDF5
# HDF5DIR=/data46/rolson/utilities/HDF5/1.8.22/hdf5-1.8.22/hdf5 #Parallel, Intel
# export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${HDF5DIR}/lib

# #Libcurl
# CURLDIR=/data46/rolson/utilities/curl/7.82.0/lib
# export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${CURLDIR}

# # netCDF
# # Parallel, Intel compiler
# NETCDFDIR=/data46/rolson/utilities/netcdf-C
# export PATH=/data46/rolson/utilities/netcdf-C/bin:${PATH}
# export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${NETCDFDIR}/lib

# PLPLOT_PATH=/data46/rolson/utilities/PLplot-ifort
# export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${PLPLOT_PATH}/lib
# PKG_CONFIG_PATH=${PKG_CONFIG_PATH}:${PLPLOT_PATH}/lib/pkgconfig
# #============================================================

#=============================================================
# ILS SETTINGS. ALSO TO BE USED WITH EBM EMULATOR.
# To be used with MPI settings 12u
export ILS_SYS=isotope3
NETCDFDIR=/usr/local/netcdf-4.7.0
export PATH=$NETCDFDIR/bin:${PATH}
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${NETCDFDIR}/lib
#=============================================================
```

Note that the stand-alone emulator version must be used with "3u" MPI settings:

`>> mpi-selector-menu`

Type "3u"

The coupled emulator, however, needs the "12u" settings. 

Dependencies -- specific procedure for Wisteria-Aquarius
------------------------
On Wisteria-Aquarius the coupled emulator runs with the following setup: ifort (IFORT) 2021.8.0 20221119, Intel MPI library impi/2021.8.0, and netCDF-Fortran 4.6.0 libraries. The commands that set the environment up are: 
```
# Set some vars
export ILS_SYS=aquarius

module load intel
module load impi
module load hdf5
module load phdf5
module load netcdf
module load netcdf-fortran
NETCDFDIR=/work/opt/local/x86_64/apps/intel/2023.0.0/netcdf-fortran/4.6.0
PATH=$NETCDFDIR/bin:${PATH}
LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:${NETCDFDIR}/lib
```
> [!NOTE]
>  Due to bug in Intel OneAPI, the stand-alone emulator does not run on Wisteria-Aquarius. It is expected that the problem is going to be solved when the newer version of Intel OneAPI is properly installed. 


# COMPILING AND RUNNING
## Stand-alone emulator
- Turn on all libraries needed by the stand-alone emulator in the environmental settings (e.g., by uncommenting relevant parts of the `.bashrc` file and starting a new shell
- Within the ILS tree, navigate to the `/src/ext/runoff_model_emulator` directory
- At the top of the Makefile, turn the coupled option off:
  `COUPLED=F`
- In the same file, specify the number of processors (there are restrictions on allowed number of processors). The default is 16.
  `NPROC=16`
- Compile the code
```
>>./cleanup 
>> make run_plot_emul_sp.exe
```
- Specify settings in the control file. See inside `src/emul/types.f90` (search for "GENERAL OPTIONS") for the description of control file options. 
- Run `/run_plot_emul_sp.exe` from the `/bin` folder
 ```
  >> cd bin
  >> ./run_plot_emul_sp
 ```
- netCDF output is going to be in the `/bin/out` directory by default

> [!NOTE]
> Please call `cleanup` every time you remake the code. 

> [!NOTE]
>  The Makefile needs the `pkg-config` utility to work. Please make sure
it is in your path, or install it if you don't have it. 
  
## Coupled emulator
### Compile the emulator
- Turn on all libraries needed by the coupled emulator in the environmental settings (e.g., by uncommenting relevant parts of the `.bashrc` file and starting a new shell
- Change `ILS_EMUL` in the `ILS/src/Mkinclude` to `T`. This switches CaMa-Flood to the mixed precision mode, which is faster. 
- Compile the ILS first (see ILS manual). This prepares coupling libraries needed by the ILS emulator. 
- Now, compile the ILS emulator. Within the ILS tree, navigate to the `/src/ext/runoff_model_emulator` directory
- At the top of the Makefile, turn the coupled option on:
  `COUPLED=T`
- In the same file, make sure you use a single processor
  `NPROC=1`
- Compile the code 
```
>>./cleanup 
>> make emul_coupled.exe
```
- The generated executable (in `/bin`) can now be used as a valid ILS component. See ILS documentation for more details. Next subsections describe how to prepare all necessary configuration files, forcings, etc. as you would normally do when running ILS.

### Prepare the emulator forcings
> [!NOTE]
>  For the Couplethon 2024, the forcings for years 2005-2010 are already prepared. They are in `/data1/ILS_Couplethon_2024/2005-2010`. 

Emulator is forced by five variables, all of which should be *one-day ahead* values. (This quirk is needed in the context of the implicit integration scheme). For examples, data for Jan 1 00:00 should actually be the value for Jan 2 00:00 (in practice we use the mean for Jan 2 instead of Jan 2 00:00 value). The variables are Snowf_new (snowfall rate [kg m-2 s-1]), Tair_new (near-surface air temperature [K]), Rainf_new (rainfall rate [kg m-2 s-1]), Qair_new (near-surface specific humidify [unitless]), and Psurf_new (surface air pressure [Pa]). All times should be midnight (00:00 hr). The time scale is daily. 

### Prepare boundary conditions
> [!NOTE]
>  For the Couplethon 2024, the boundary conditions are provided. They are located in `/data1/ILS_Couplethon_2024/ILS_data`. Please copy this directory into the top-level directory `ILS`. The forcings are now in `.../ILS/ILS_data/test/`

To create boundary conditions, you can follow standard ILS procedures. Note that the MATSIRO emulator does not need any boundary conditions. Therefore, please prepare boundary conditions for CaMa-Flood only

### Prepare optimized emulator parameters
The emulator takes in fields of emulator parameters. These files are dumped by stand-alone emulator after optimizing the parameters to best fit MATSIRO. There are 16 parameters in total, and they vary with month. According to the new file style, each emulator parameter goes to its own
file. The files should be named `emulpar[1-16].nc`. The corresponding
emulator parameters should also be named `emulpar[1-16]`. This is the only style working with the coupled emulator. 

> [!NOTE]
>  For the Couplethon 2024, the emulator parameter files are provided. They are located in `/data1/ILS_Couplethon_2024/2005-2010` directory. 

### Prepare initial conditions
> [!NOTE]
>  For the Couplethon 2024, the initial conditions are provided. They are located in `/data1/ILS_Couplethon_2024/restart`. Please copy the files in this directory to the `.../ILS/runs/out` subdirectory. The file `restart.bin` is the standard MATSIRO restart file. ILS emulator can be initialized from MATSIRO state, and this is what we plan to do. The file `restart.cama.2005010100.bin` is the CaMa-Flood restart file.

Please follow standard ILS procedures when creating boundary condition files. The MATSIRO emulator can be restarted either from MATSIRO restart file, or from MATSIRO emulator restart file (see next subsection)

### Prepare configuration files and submit scripts
> [!NOTE]
>  For the Couplethon 2024, configuration files and submit scripts are provided. They are in the `/data46/rolson/ILS_Couplethon_2024/conf_files` subdirectory. Please copy them to your `...ILS/runs` subdirectory. 
- Compared to the ILS, the configuration file `matsiro.conf` is no longer used. It is replaced by the `emul.conf` file, which is shorter and more concise.
- Please make changes in the additional emulator configuration file `emul.conf` in the `runs` subdirectory. Sample configuration files are provided in the `runs/run_emul` subdirectory. Some notes on the configuration file. The restart type is specified using the `restart` argument. "no" - no restart; "emul" - restart from the emulator restart file `restart.emul.bin`; "matsiro" - restart from the MATSIRO restart file `restart.bin`. Otherwise, please see comments in the `emul.conf` configuration file
- The submit script is similar to ILS, but the MATSIRO executable should be replaced with its emulator. Sample submit script is provided in the `runs/run_emul` subdirectory.
- There is additional configuration file `ILS.json` that specified units, names and other attributes of the output variables. It is also necessary to use the emulator


### Run the emulator
- The emulator is now ready to run. Relax, sit back, enjoy.
> [!TIP]
> In a few moments you will most likely get the segmentation fault. This means that some settings are incorrect. In this case, please repeat the setup procedure and check the configuration files. If this problem does not go away with a lot of effort, you can contact me by email or in person. Or, if you are really lucky, the program will run perfectly from the start.

## Diagnostics
The emulator can print out input forcing and emulator parameters for checking purposes. This can be specified in the `coupling.conf` and `ilsio.conf` configuration files. In addition, each processor outputs `log_emulator.txt-[processor number]` log file. Please check these log files for diagnostic information. 

# EMULATOR OBJECTS
## New File Style
According to the new file style, each emulator parameter goes to its own
file. The files should be named `emulpar[1-16].nc`. The corresponding
emulator parameters should also be named `emulpar[1-16]`. This is the only style working with the coupled emulator. 

## Old File Style
Old emulators had all 16 parameters in one file. The file name is `emul.in.nc`
and it should be placed in the same directory as the final executable. 
For the stand-alone emulator, there is an option to read either new or old file style in the `control.in`
file. 

## Sample Pre-saved emulator (old style)
A sample emulator fitted over Japan has been pre-trained and saved in
`emulators/emul.sample.nc`. The corresponding control file used for its fitting
is also saved as `control.sample.nc`. How to run the pre-trained emulator (in stand-alone form)

1. Save the emulator as `bin/emul.in.nc`
2. Follow the instructions on "how to run". Use the `emulators/control.sample.in`
as an example, and make sure you set usesaved to `.true.` in the control file

# OTHER
## Allowed configurations (for the stand-alone emulator)
For simplicity, the total number of
processors is restricted to a square of an integer, `n^2`. Consider that there
are `n*k` grid points in longitude and `n*l` grid points in the latitude directions.
The parallelization is staggered to avoid higher load on certain
cores due to higher land fraction in areas of the globe. Specifically, if a
total of `n^2` processors are engaged, mth core processes latitude indices
`([m - 1] mod n)+ n*i+ 1, i = 0, …, k - 1,` where mod denotes the
remainder; and longitude indices `([m - 1] div n)+ n*i+ 1, i = 0,…,l - 1,`
where div is the quotient of Euclidean division. Thus, non-rectangular
regions are allowed, within certain restrictions. The emulator can,
therefore, be used for a range of spatial regions up to the global scale at
0.5deg resolution. In practice, the smallest tested region using 16 cores was
a 4 × 4 grid point block, with 1 grid point for each core.

## Testing
NOTE: Test files have been recently moved away from the repository. They are now located in /data46/rolson/test_files_ILS
This has been done to save space. If performing testing, you will need access to Isotope3 in order to look at these files. 

The emulator comes with an extensive test suite. Most program have test 
functions.  To test a specific function run (in the `/src/ext/runoff_model_emulator` directory)
 ```
  >>./cleanup
  >> make [test_mysubroutine.exe]
  >> cd tests
  >> ./test_mysubroutine.exe
  ```
Please do not forget to run `./cleanup every` time you compile 

To write new tests, one can start with
a stub program `tests/test_stub.f90` and modify it as needed.

# INPUT, STATE AND OUTPUT
## State variables
 - snow storage [kg m-2]
 - wetland storage [kg m-2] 
 - total soil moisture [kg m-2]

## Forcing variables
 - snowfall [kg m-2 day-1]
 - near-surface air temperature [K]
 - rainfall [kg m-2 day-1]
 - near-surface specific humidity [kg/kg]
 - pressure [Pa]

## Output
 - runoff. Standalone emulator uses [kg m-2 day-1], but the coupled emulator
   uses [kg m-2 sec-1] to be consistent with CaMa-Flood.

# ADVANCED
## Parallelization method (stand-alone emulator)
 When storing climate data, the entire region is split into many square tiles.
 Each processor looks
 only at a particular grid point within each tile. For example, core 1
 considers data at the bottom left cell within each tile, core 2
 considers the secondmost left position at the bottom and so forth. The
 column (longitude) within the tiles changes fastest as the processor index 
 increases, while the row (latitude) within the tile changes slowest. The 
 last processor looks at the top right cell within each tile. 

 The emulator, however, is stored globally across processors. However, 
 each processor only uses emulator parameters for the latitudes and longitudes
 which are corresponding to the data it manages. The emulator parameters are
 allocated using shifted indices (i.e., the indices do not have to start from
 1)

 loninds and latinds (e.g., components of state and forcing, etc.) are
 generally defined as indices with respect to the global grid of the
 state and forcing. On these grids longitude starts at -179.75 and increases
 in half-degree increments, and latitude decreases from 89.75 in half-degree
 decrements. 

## What do different images do (stand-alone emulator)
- Image 1  => User I/O
- Image 2  => Profiling
- Image 16 => Heavy on other I/O 

## Standard testing configuration (stand-alone emulator)
 For testing, the model is to be compiled with 16 images on 16 nodes,
 this makes for 
 `4\*4` size latitude/longitude tiles. Therefore, the minimum region size
 is `4\*4` points. All tests are written for this configuration. Testing for
 other configurations has to be done manually, by comparing the output
 of other configurations with the output from the 16-image configurations. 

## Timing (stand-alone emulator)
There is a special type "timer", which is a component of the main "work" type. The work type is initialized at the beginning of the program. Assuming that the name of the work type is "worktp", the timer is `worktp%tmr`. To initialize the timer use: 
```
res = worktp%tmr%init()
```
(`res` is a dummy variable for the function output).
The timer does not understand parallelization. The best way is to sync all images before and after timing. To time a specific component "comp" use:
```
sync all
res = worktp%tmr%start("comp")
sync all
```
...
```
sync all
res = worktp%tmr%stop("comp")
sync all
```
To print timer output to the appropriate unit use: `res=worktp%tmr%print(worktp%out_units(2))`. Note that the second element of `worktp%out_units` is the appropriate unit for timer output. It is printed by the image with the same number. 


## Notes on the control file/parameters (stand-alone emulator)
when specifying the lower bounds (lb) and upper bounds (lb), the order is as
follows:
     1=> a [unitless]  
     2=> b [kg m-2 day-1 K**-xi]  
     3=> Tc [K]. 
     4=> xi [unitless]  
     5=> c  [unitless]  
     6=> d  [unitless]  
     7=> omega [day-1]  
     8=> g  [kg m-2 day-1]  
     9=> T0  [K]  
     10=> y0  [kg m-2]  
     11=> y_E  [kg m-2]  
     12=> k1 [m2 kg-1]  
     13=> y* [kg m-2]  
     14=> k2 [m2 day kg-1]  
     15=> Pin* [kg m-2 day-1]  
     16=> k3 [m2 kg-1]  
Note that the limits for omega are effectively ignored, as it is calculated
from the MATSIRO boundary conditions.   

## Other notes (stand-alone emulator)
Indices of points in the code start at 1 from the top left of the domain

# References
1.	R. Olson, K. Yoshimura and T. Nitta (2024): A fast physically-guided 
emulator of MATSIRO land surface model. Journal of Hydrology, 634, 131093,
 doi: 10.1016/j.jhydrol.2024.131093
2. Emulator structure (n.d.), Powerpoint Presentation. Available from
Roman Olson on request (documents changes since Olson et al. (2024)). 
