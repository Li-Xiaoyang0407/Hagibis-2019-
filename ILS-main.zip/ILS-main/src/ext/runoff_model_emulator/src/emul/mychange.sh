#!/bin/bash
# To perform operations on all Fortran files, to save backups as
# *.backup

# Change the sed line as needed and run. 

MYFILES=($(find . -name "*.f90"))
echo ${MYFILES[@]}
NFILES=${#MYFILES[@]}
echo $NFILES
# Loop over all files

for (( NFILE=0; NFILE<=NFILES-1; NFILE++ )); do

   MYFILE=${MYFILES[NFILE]}
   echo "================"
   echo "File is:" $MYFILE
   echo "================"
   #Replaced print statements with write statements to unit 1
   #sed --in-place=.backup 's/print \*\,/write(1,\*)/g' $MYFILE

   #Deletes lines ending with set_up() and tear_down()
   #sed --in-place=.backup '/set_up()$/d ; /tear_down()$/d' $MYFILE
   diff $MYFILE ${MYFILE}.backup

done
echo ""
