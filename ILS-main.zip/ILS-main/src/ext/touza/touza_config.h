/* manually adjusted to minimum implementation on ILS */
/* touza_config.h.  Generated from touza_config.h.in by configure.  */
/* touza_config.h.in.  Generated from configure.ac by autoheader.  */

/* cal is enabled */
#define ENABLE_TOUZA_CAL 1

/* std is enabled */
#define ENABLE_TOUZA_STD 1

/* prefer elemental function */
/* #define OPT_ENABLE_FORTRAN_ELEMENTAL 1 */

/* fortran i/o unit for stderr */
#define OPT_STDERR_UNIT 0

/* fortran i/o unit for stdin */
#define OPT_STDIN_UNIT 5

/* fortran i/o unit for stdout */
#define OPT_STDOUT_UNIT 6

/* Define if you use mpi */
#define OPT_USE_MPI 1

/* Name of package */
#define PACKAGE "touza"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "saitofuyuki@jamstec.go.jp"

/* Define to the full name of this package. */
#define PACKAGE_NAME "touza"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "touza 1.00.4"

/* package name */
#define PACKAGE_TAG 'TOUZA'

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "touza"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.00.4"

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1

/* Version number of package */
#define VERSION "1.00.4"
