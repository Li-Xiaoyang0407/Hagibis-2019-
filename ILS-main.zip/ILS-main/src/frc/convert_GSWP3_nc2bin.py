import os
import numpy as np
from netCDF4 import Dataset, num2date

'''
Convert netCDF to plain binary
The data is backward mean (0:00 is for 21:00-24:00)
'''

def main():
    in_dir = '../../data/GSWP3/EXP1'
    out_dir = '../../ILS_data/gswp3/frc'

    vars = [
        'SWdown',
        'LWdown',
        'Rainf',
        'Snowf',
        'Qair',
        'Tair',
        'Wind',
        'PSurf',
        ]

    start_year = 2000
    end_year = 2000
    last_year = 2010

    for year in range(start_year, end_year+1):
        for var in vars:
            print('%s %4.4i'%(var,year))
            path = os.path.join(
                       in_dir, var,
                       'GSWP3.BC.%s.3hrMap.%4.4i.nc'%(var,year))
            nc = Dataset(path)

            out_path = os.path.join(
                           out_dir,
                           'GSWP3.BC.%s.3hrMap.%4.4i.bin'%(var,year))
            shape = nc.variables[var].shape
            shape = (shape[0]+1, shape[1], shape[2])
            out_data = np.memmap(out_path, dtype='float32', mode='w+', shape=shape)

            if var in ['SWdown', 'LWdown', 'Rainf', 'Snowf']:
                t_start = 1
            else:
                t_start = 0
            t_end = nc.variables['time'].shape[0]

            fmt = '%s %%Y%%m%%d-%%H'%var

            icounter = 0
            for i in range(t_start, t_end):
                # print(num2date(nc.variables['time'][i],
                #                nc.variables['time'].units).strftime(fmt))
                d = np.roll(nc.variables[var][i,:,:], 360, axis=1)
                d = d[::-1,:]
                out_data[icounter,:,:] = d[:,:].byteswap()
                icounter += 1


            if year == last_year:
                path = os.path.join(
                           in_dir, var,
                           'GSWP3.BC.%s.3hrMap.%4.4i.nc'%(var,year))
            else:
                path = os.path.join(
                           in_dir, var,
                           'GSWP3.BC.%s.3hrMap.%4.4i.nc'%(var,year+1))
            nc = Dataset(path)

            t_start = 0
            if var in ['SWdown', 'LWdown', 'Rainf', 'Snowf']:
                t_end = 2
            else:
                t_end = 1

            for i in range(t_start, t_end):
                # print(num2date(nc.variables['time'][i],
                #                nc.variables['time'].units).strftime(fmt))
                d = np.roll(nc.variables[var][i,:,:], 360, axis=1)
                d = d[::-1,:]
                out_data[icounter,:,:] = d[:,:].byteswap()
                icounter += 1


if __name__ == '__main__':
    main()

