import calendar
import os
import numpy as np

def main():
    in_dir = '../../data/GSWP3/EXP1/CCOV'
    out_dir = '../../ILS_data/gswp3/frc/'

    start_year = 1901
    end_year = 2010
    last_year = 2010

    nx = 720
    ny = 360

    for year in range(start_year, end_year+1):
        if calendar.isleap(year):
            nt = 366 * 8 + 1
        else:
            nt = 365 * 8 + 1

        out_path = os.path.join(out_dir, 'GSWP3.BC.CCover.3hrMap.%4.4i.bin'%year)
        out_data = np.memmap(out_path, dtype='float32', mode='w+', shape=(nt,ny,nx))
        icounter = 0

        for mon in range(1, 13):
            print('CCOV %4.4i-%2.2i'%(year, mon))

            path = os.path.join(in_dir, 'CCOV.ra05.%4.4i%2.2i.npy'%(year, mon))
            in_data = np.load(path)
            in_data = in_data / 100.0  # % -> ratio

            if mon == 1:
                ts = 1
            else:
                ts = 0

            for i in range(ts, in_data.shape[0]):
                d = np.roll(in_data[i,...], 360, axis=1)
                d = d[::-1,:]
                out_data[icounter,...] = d[:,:].byteswap()
                icounter += 1


        if year == last_year:
            path = os.path.join(in_dir, 'CCOV.ra05.%4.4i%2.2i.npy'%(year, 1))
        else:
            path = os.path.join(in_dir, 'CCOV.ra05.%4.4i%2.2i.npy'%(year+1, 1))
        in_data = np.load(path)
        in_data = in_data / 100.0  # % -> ratio

        for i in range(0, 2):
            d = np.roll(in_data[i,...], 360, axis=1)
            d = d[::-1,:]
            out_data[icounter,...] = d[:,:].byteswap()
            icounter += 1



if __name__ == '__main__':
    main()


