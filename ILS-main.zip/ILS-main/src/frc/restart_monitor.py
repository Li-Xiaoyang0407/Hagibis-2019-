import numpy as np
import re
import matplotlib.pyplot as plt

class RestartData():
    data = np.zeros(0)
    def __init__(self, data_name, my_rank):
        self.data_name = data_name
        self.my_rank   = my_rank

rest_data = list()
data_list = list()

def read_ici_log(file_name):
    with open(file_name) as f:
        for line in f:
            if ("get_and_write_data" in line):
                data_list.append(line.rsplit(None,1)[1][:-4])

def read_restart_file(file_name, data_num):
    offset = 0
    size   = 0 
    data = np.zeros(0)
    for dt in range(data_num + 1):
        size = np.fromfile(file_name, dtype='int32', count=1, offset=offset).byteswap()
        data = np.fromfile(file_name, dtype='float', count=int(size/8), offset = offset+4).byteswap()
        offset += 4 + 4 + int(size)
    return data
    
RESTART_DIR  = "../../runs/out/"
RESTART_FILE = "ici.RESTART.2000010300.MATSIRO"

NUM_OF_PE = 8
DATA_NAME = "Tair"

for i in range(NUM_OF_PE):
    rest_data.append(RestartData(DATA_NAME, i))
                     
read_ici_log(RESTART_DIR+"ici.MATSIRO.log.PE00000")
print(data_list)
data_num = data_list.index(DATA_NAME) 

gdata = np.zeros(0)

for i in range(NUM_OF_PE):
    num_str = str(i)
    file_name = RESTART_DIR + RESTART_FILE + '.PE' + num_str.zfill(5)
    rest_data[i].data = read_restart_file(file_name, data_num)
    gdata = np.append(gdata, rest_data[i].data)


path = '../../ILS_data/test/cama/grdare.bin'
area = np.fromfile(path, dtype='float32').byteswap().reshape(360, 720)

counter = 0

for j in range(360):
    for i in range(720):
        if (area[j,i] > -9999):
            area[j,i] = gdata[counter]
            counter = counter + 1

plt.imshow(np.ma.masked_equal(area, -9999), interpolation='nearest', cmap=plt.cm.jet)
plt.colorbar()
plt.title('Grid area')
plt.show()

    
