#!/bin/sh
rev=$1
test x"$rev" = x && rev=HEAD
COMMITID=`git rev-parse $rev`  || COMMITID=unavailable
INSTR='"commitid": "'${COMMITID}'",'
SYSINFO='"system": "'${ILS_SYS}'",'
MAKEDATE=`date +"%Y-%m-%dT%H:%M:%S%z"`
MAKEDATE='"makedate": "'${MAKEDATE}'",'
SP="        "
echo "$SP"$INSTR
echo "$SP"$SYSINFO
echo "$SP"$MAKEDATE
