import numpy as np
from netCDF4 import Dataset

dir1 = 'out'
dir2 = 'out.org'
variables = ['SoilMoistV', 'Qle', 'Qh']

for var in variables:
    nc1 = Dataset('{}/{}.nc'.format(dir1, var))
    nc2 = Dataset('{}/{}.nc'.format(dir2, var))
    data1 = nc1.variables[var][:]
    data2 = nc2.variables[var][:]

    print('Maxmum difference of {}: '.format(var),
          np.ma.max(np.ma.abs(data1-data2)))

