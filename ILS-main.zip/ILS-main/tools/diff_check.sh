#!/bin/bash

cd `pwd`
data_dir1=./out
data_dir2=./out.2
# data_dir2=./out_df
#binFiles=($(cd ${data_dir1}; file * | grep -i "fort"| cut -d: -f1 | xargs))
binFiles=($(cd ${data_dir1}; ls -l *nc |awk '{print $9}' | xargs))
echo ${binFiles[@]}

printf "*** Reference Data dir: %s ***\n" ${data_dir1}
for((i=0,j=1;i<${#binFiles[@]};i++,j++));do
        binFile=${binFiles[$i]}
        printf "%2d: [%-16s] " $j ${binFile}
        diff -sq ${data_dir1}/${binFile} ${data_dir2}/${binFile}
#       printf "\n"
done

exit $?
